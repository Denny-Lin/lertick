---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:51:18
      epoch-secs: 1795333878
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377682
      totalram: 4080812032
      freeram: 1868038144
      sharedram: 3543040
      bufferram: 35991552
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 32200658
      bogo-ops-per-second-usr-sys-time: 373471.536628
      bogo-ops-per-second-real-time: 2012493.057210
      wall-clock-time: 16.000382
      user-time: 4.633837
      system-time: 81.586008
      cpu-usage-per-instance: 67.357645
      max-rss: 2176

...
