---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:46:42
      epoch-secs: 1795333602
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377406
      totalram: 4080812032
      freeram: 1922875392
      sharedram: 3543040
      bufferram: 35897344
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19885078
      bogo-ops-per-second-usr-sys-time: 225194.325180
      bogo-ops-per-second-real-time: 1242758.298537
      wall-clock-time: 16.000761
      user-time: 5.320169
      system-time: 82.981692
      cpu-usage-per-instance: 68.982550
      max-rss: 2156

...
