---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:48:33
      epoch-secs: 1795333713
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377517
      totalram: 4080812032
      freeram: 1879760896
      sharedram: 3543040
      bufferram: 35958784
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 51958
      bogo-ops-per-second-usr-sys-time: 810.241144
      bogo-ops-per-second-real-time: 3247.176717
      wall-clock-time: 16.000977
      user-time: 2.701063
      system-time: 61.425525
      cpu-usage-per-instance: 50.095838
      max-rss: 2152

...
