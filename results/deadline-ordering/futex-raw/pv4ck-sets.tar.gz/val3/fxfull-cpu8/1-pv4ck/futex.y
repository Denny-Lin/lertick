---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:53:06
      epoch-secs: 1795333986
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377790
      totalram: 4080812032
      freeram: 1881796608
      sharedram: 3543040
      bufferram: 36036608
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 14175792
      bogo-ops-per-second-usr-sys-time: 168228.162033
      bogo-ops-per-second-real-time: 885950.706892
      wall-clock-time: 16.000655
      user-time: 4.606295
      system-time: 79.658978
      cpu-usage-per-instance: 65.829548
      max-rss: 2152

...
