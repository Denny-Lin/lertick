---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:50:20
      epoch-secs: 1795333820
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377625
      totalram: 4080812032
      freeram: 1878454272
      sharedram: 3543040
      bufferram: 35975168
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 13143270
      bogo-ops-per-second-usr-sys-time: 157145.370877
      bogo-ops-per-second-real-time: 821390.008132
      wall-clock-time: 16.001254
      user-time: 4.546752
      system-time: 79.090901
      cpu-usage-per-instance: 65.336796
      max-rss: 2152

...
