---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:56:44
      epoch-secs: 1795334204
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378008
      totalram: 4080812032
      freeram: 1870479360
      sharedram: 3543040
      bufferram: 36663296
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 17137602
      bogo-ops-per-second-usr-sys-time: 198609.715926
      bogo-ops-per-second-real-time: 1071037.874159
      wall-clock-time: 16.000930
      user-time: 4.724136
      system-time: 81.563697
      cpu-usage-per-instance: 67.408452
      max-rss: 2152

...
