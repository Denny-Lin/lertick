---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:47:40
      epoch-secs: 1795333660
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377464
      totalram: 4080812032
      freeram: 1874628608
      sharedram: 3543040
      bufferram: 35950592
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 31329822
      bogo-ops-per-second-usr-sys-time: 365374.997873
      bogo-ops-per-second-real-time: 1958072.318873
      wall-clock-time: 16.000340
      user-time: 4.864448
      system-time: 80.882585
      cpu-usage-per-instance: 66.988448
      max-rss: 2176

...
