---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:54:56
      epoch-secs: 1795334096
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377900
      totalram: 4080812032
      freeram: 1866391552
      sharedram: 3543040
      bufferram: 36638720
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 31703660
      bogo-ops-per-second-usr-sys-time: 368556.818600
      bogo-ops-per-second-real-time: 1981433.195604
      wall-clock-time: 16.000368
      user-time: 4.779729
      system-time: 81.241363
      cpu-usage-per-instance: 67.202433
      max-rss: 2152

...
