---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:52:12
      epoch-secs: 1795333932
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377736
      totalram: 4080812032
      freeram: 1879437312
      sharedram: 3543040
      bufferram: 36003840
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 79786
      bogo-ops-per-second-usr-sys-time: 1243.364191
      bogo-ops-per-second-real-time: 4986.402685
      wall-clock-time: 16.000713
      user-time: 1.994942
      system-time: 62.174511
      cpu-usage-per-instance: 50.130150
      max-rss: 2180

...
