---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:58:34
      epoch-secs: 1795334314
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378118
      totalram: 4080812032
      freeram: 1861050368
      sharedram: 3543040
      bufferram: 36724736
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 25126872
      bogo-ops-per-second-usr-sys-time: 325705.682281
      bogo-ops-per-second-real-time: 1570349.553791
      wall-clock-time: 16.000815
      user-time: 4.796475
      system-time: 72.349468
      cpu-usage-per-instance: 60.267200
      max-rss: 2212

...
