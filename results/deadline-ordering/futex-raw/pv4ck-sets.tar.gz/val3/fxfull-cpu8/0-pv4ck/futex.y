---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:49:27
      epoch-secs: 1795333767
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377571
      totalram: 4080812032
      freeram: 1885863936
      sharedram: 3543040
      bufferram: 35971072
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 20779894
      bogo-ops-per-second-usr-sys-time: 234302.831076
      bogo-ops-per-second-real-time: 1298667.342362
      wall-clock-time: 16.000937
      user-time: 4.993386
      system-time: 83.694804
      cpu-usage-per-instance: 69.283592
      max-rss: 2152

...
