---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:00:20
      epoch-secs: 1795334420
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378224
      totalram: 4080812032
      freeram: 1866104832
      sharedram: 3543040
      bufferram: 36745216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19218414
      bogo-ops-per-second-usr-sys-time: 218031.576232
      bogo-ops-per-second-real-time: 1201103.696294
      wall-clock-time: 16.000628
      user-time: 4.999781
      system-time: 83.145314
      cpu-usage-per-instance: 68.860651
      max-rss: 2152

...
