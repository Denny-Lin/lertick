---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:57:37
      epoch-secs: 1795334257
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378061
      totalram: 4080812032
      freeram: 1868992512
      sharedram: 3543040
      bufferram: 36675584
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 6824490
      bogo-ops-per-second-usr-sys-time: 86231.423747
      bogo-ops-per-second-real-time: 426498.490899
      wall-clock-time: 16.001206
      user-time: 4.104626
      system-time: 75.036941
      cpu-usage-per-instance: 61.824691
      max-rss: 2152

...
