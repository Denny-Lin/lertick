---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:55:50
      epoch-secs: 1795334150
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377955
      totalram: 4080812032
      freeram: 1870450688
      sharedram: 3543040
      bufferram: 36655104
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 49134
      bogo-ops-per-second-usr-sys-time: 766.150177
      bogo-ops-per-second-real-time: 3070.721204
      wall-clock-time: 16.000801
      user-time: 2.030612
      system-time: 62.100418
      cpu-usage-per-instance: 50.099858
      max-rss: 2156

...
