---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 07:53:59
      epoch-secs: 1795334039
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 377843
      totalram: 4080812032
      freeram: 1883885568
      sharedram: 3543040
      bufferram: 36167680
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19668636
      bogo-ops-per-second-usr-sys-time: 223232.030377
      bogo-ops-per-second-real-time: 1229254.493740
      wall-clock-time: 16.000459
      user-time: 5.335334
      system-time: 82.773151
      cpu-usage-per-instance: 68.832780
      max-rss: 2152

...
