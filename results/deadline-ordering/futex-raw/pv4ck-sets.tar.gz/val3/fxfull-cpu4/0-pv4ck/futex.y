---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:03:59
      epoch-secs: 1795334639
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378443
      totalram: 4080812032
      freeram: 1863913472
      sharedram: 3522560
      bufferram: 36859904
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 21284810
      bogo-ops-per-second-usr-sys-time: 470242.050778
      bogo-ops-per-second-real-time: 1330275.519614
      wall-clock-time: 16.000302
      user-time: 4.379120
      system-time: 40.884399
      cpu-usage-per-instance: 70.722914
      max-rss: 2152

...
