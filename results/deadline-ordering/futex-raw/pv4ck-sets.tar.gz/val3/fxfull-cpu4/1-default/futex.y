---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:05:50
      epoch-secs: 1795334750
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378554
      totalram: 4080812032
      freeram: 1877037056
      sharedram: 3522560
      bufferram: 36913152
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28785390
      bogo-ops-per-second-usr-sys-time: 665899.968675
      bogo-ops-per-second-real-time: 1799062.057389
      wall-clock-time: 16.000221
      user-time: 5.664703
      system-time: 37.563096
      cpu-usage-per-instance: 67.542504
      max-rss: 2176

...
