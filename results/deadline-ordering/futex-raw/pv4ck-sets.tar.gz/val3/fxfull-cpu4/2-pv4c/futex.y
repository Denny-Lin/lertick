---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:08:30
      epoch-secs: 1795334910
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378715
      totalram: 4080812032
      freeram: 1865867264
      sharedram: 3522560
      bufferram: 36982784
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 15444742
      bogo-ops-per-second-usr-sys-time: 353784.333545
      bogo-ops-per-second-real-time: 965266.823901
      wall-clock-time: 16.000490
      user-time: 2.321550
      system-time: 41.334261
      cpu-usage-per-instance: 68.210116
      max-rss: 2176

...
