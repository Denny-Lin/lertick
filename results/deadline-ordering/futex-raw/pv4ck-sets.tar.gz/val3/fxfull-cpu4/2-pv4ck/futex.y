---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:11:14
      epoch-secs: 1795335074
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378878
      totalram: 4080812032
      freeram: 1868660736
      sharedram: 3522560
      bufferram: 37052416
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 18620832
      bogo-ops-per-second-usr-sys-time: 418887.584617
      bogo-ops-per-second-real-time: 1163770.707200
      wall-clock-time: 16.000430
      user-time: 3.404651
      system-time: 41.048402
      cpu-usage-per-instance: 69.456028
      max-rss: 2156

...
