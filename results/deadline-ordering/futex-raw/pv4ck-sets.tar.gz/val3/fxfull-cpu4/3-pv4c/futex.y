---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:12:07
      epoch-secs: 1795335127
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378932
      totalram: 4080812032
      freeram: 1867743232
      sharedram: 3522560
      bufferram: 37072896
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 18216438
      bogo-ops-per-second-usr-sys-time: 410555.373677
      bogo-ops-per-second-real-time: 1138509.078132
      wall-clock-time: 16.000257
      user-time: 3.380417
      system-time: 40.989817
      cpu-usage-per-instance: 69.327376
      max-rss: 2176

...
