---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 08:09:28
      epoch-secs: 1795334968
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 378772
      totalram: 4080812032
      freeram: 1867763712
      sharedram: 3522560
      bufferram: 37003264
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28749944
      bogo-ops-per-second-usr-sys-time: 665580.190739
      bogo-ops-per-second-real-time: 1796843.279096
      wall-clock-time: 16.000251
      user-time: 5.675181
      system-time: 37.520131
      cpu-usage-per-instance: 67.491615
      max-rss: 2204

...
