---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:13:11
      epoch-secs: 1795338791
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382595
      totalram: 4080812032
      freeram: 2324885504
      sharedram: 3543040
      bufferram: 18857984
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 542945
      bogo-ops-per-second-usr-sys-time: 4549.245930
      bogo-ops-per-second-real-time: 36194.626999
      wall-clock-time: 15.000707
      user-time: 119.343353
      system-time: 0.004998
      cpu-usage-per-instance: 99.452271
      max-rss: 2560
      add-matrix-ops-per-sec: 324939.579953
      copy-matrix-ops-per-sec: 443110.509072
      div-matrix-ops-per-sec: 495297.694899
      frobenius-matrix-ops-per-sec: 80853.985997
      hadamard-matrix-ops-per-sec: 367404.729704
      identity-matrix-ops-per-sec: 394865.513699
      mean-matrix-ops-per-sec: 402212.345639
      mult-matrix-ops-per-sec: 527937.186907
      negate-matrix-ops-per-sec: 547680.797173
      prod-matrix-ops-per-sec: 634.931827
      sub-matrix-ops-per-sec: 408684.875112
      square-matrix-ops-per-sec: 677.535424
      trans-matrix-ops-per-sec: 147487.670799
      zero-matrix-ops-per-sec: 886678.832244

...
