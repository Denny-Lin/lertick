---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:12:41
      epoch-secs: 1795338761
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382565
      totalram: 4080812032
      freeram: 2306629632
      sharedram: 3543040
      bufferram: 18849792
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 98390
      bogo-ops-per-second-usr-sys-time: 818.207044
      bogo-ops-per-second-real-time: 3279.574685
      wall-clock-time: 30.000841
      user-time: 3.912088
      system-time: 116.338649
      cpu-usage-per-instance: 50.103069
      max-rss: 2152

...
