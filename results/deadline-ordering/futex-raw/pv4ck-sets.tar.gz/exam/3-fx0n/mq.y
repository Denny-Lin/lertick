---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:12:56
      epoch-secs: 1795338776
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382580
      totalram: 4080812032
      freeram: 2310705152
      sharedram: 3543040
      bufferram: 18857984
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 43249816
      bogo-ops-per-second-usr-sys-time: 360670.791819
      bogo-ops-per-second-real-time: 2883197.951901
      wall-clock-time: 15.000641
      user-time: 17.541798
      system-time: 102.373141
      cpu-usage-per-instance: 99.924849
      max-rss: 2596

...
