---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:13:26
      epoch-secs: 1795338806
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382610
      totalram: 4080812032
      freeram: 2313019392
      sharedram: 3543040
      bufferram: 18857984
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 402243
      bogo-ops-per-second-usr-sys-time: 3366.398455
      bogo-ops-per-second-real-time: 26815.905743
      wall-clock-time: 15.000165
      user-time: 43.216589
      system-time: 76.271049
      cpu-usage-per-instance: 99.571939
      max-rss: 2280

...
