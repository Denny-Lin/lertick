---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:08:53
      epoch-secs: 1795338533
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382337
      totalram: 4080812032
      freeram: 2305482752
      sharedram: 3543040
      bufferram: 18726912
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 399288
      bogo-ops-per-second-usr-sys-time: 3341.946211
      bogo-ops-per-second-real-time: 26618.847562
      wall-clock-time: 15.000199
      user-time: 42.910241
      system-time: 76.567445
      cpu-usage-per-instance: 99.563420
      max-rss: 2308

...
