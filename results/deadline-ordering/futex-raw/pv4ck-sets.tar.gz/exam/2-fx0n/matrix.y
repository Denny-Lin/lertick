---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:08:38
      epoch-secs: 1795338518
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382322
      totalram: 4080812032
      freeram: 2329800704
      sharedram: 3543040
      bufferram: 18726912
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 545484
      bogo-ops-per-second-usr-sys-time: 4553.430055
      bogo-ops-per-second-real-time: 36363.508426
      wall-clock-time: 15.000863
      user-time: 119.793286
      system-time: 0.002998
      cpu-usage-per-instance: 99.824495
      max-rss: 2560
      add-matrix-ops-per-sec: 330130.907677
      copy-matrix-ops-per-sec: 458627.892170
      div-matrix-ops-per-sec: 490532.582103
      frobenius-matrix-ops-per-sec: 82005.861421
      hadamard-matrix-ops-per-sec: 369763.515025
      identity-matrix-ops-per-sec: 396361.799051
      mean-matrix-ops-per-sec: 427051.315924
      mult-matrix-ops-per-sec: 525360.138154
      negate-matrix-ops-per-sec: 549546.802834
      prod-matrix-ops-per-sec: 637.800807
      sub-matrix-ops-per-sec: 406639.338310
      square-matrix-ops-per-sec: 680.694777
      trans-matrix-ops-per-sec: 147020.520060
      zero-matrix-ops-per-sec: 880157.932839

...
