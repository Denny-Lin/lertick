---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:08:23
      epoch-secs: 1795338503
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382307
      totalram: 4080812032
      freeram: 2327617536
      sharedram: 3543040
      bufferram: 18726912
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 40639871
      bogo-ops-per-second-usr-sys-time: 338964.860918
      bogo-ops-per-second-real-time: 2709216.228282
      wall-clock-time: 15.000601
      user-time: 16.571208
      system-time: 103.322845
      cpu-usage-per-instance: 99.907709
      max-rss: 2548

...
