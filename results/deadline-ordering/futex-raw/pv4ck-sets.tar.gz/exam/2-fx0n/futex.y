---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:08:08
      epoch-secs: 1795338488
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382292
      totalram: 4080812032
      freeram: 2311262208
      sharedram: 3543040
      bufferram: 18714624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 171716
      bogo-ops-per-second-usr-sys-time: 1426.970507
      bogo-ops-per-second-real-time: 5723.717801
      wall-clock-time: 30.000780
      user-time: 3.959912
      system-time: 116.376142
      cpu-usage-per-instance: 50.138718
      max-rss: 2176

...
