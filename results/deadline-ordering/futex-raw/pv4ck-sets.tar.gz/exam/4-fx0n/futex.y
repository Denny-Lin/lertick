---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:18:44
      epoch-secs: 1795339124
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382928
      totalram: 4080812032
      freeram: 2287218688
      sharedram: 3543040
      bufferram: 19296256
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 94126
      bogo-ops-per-second-usr-sys-time: 782.825784
      bogo-ops-per-second-real-time: 3137.450318
      wall-clock-time: 30.000794
      user-time: 4.126428
      system-time: 116.112330
      cpu-usage-per-instance: 50.098157
      max-rss: 2152

...
