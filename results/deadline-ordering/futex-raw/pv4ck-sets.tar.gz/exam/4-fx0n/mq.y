---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:18:59
      epoch-secs: 1795339139
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382943
      totalram: 4080812032
      freeram: 2292260864
      sharedram: 3543040
      bufferram: 19300352
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 42382389
      bogo-ops-per-second-usr-sys-time: 353483.374370
      bogo-ops-per-second-real-time: 2825397.489445
      wall-clock-time: 15.000505
      user-time: 17.039980
      system-time: 102.859263
      cpu-usage-per-instance: 99.912673
      max-rss: 2540

...
