---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:19:14
      epoch-secs: 1795339154
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382958
      totalram: 4080812032
      freeram: 2303528960
      sharedram: 3543040
      bufferram: 19308544
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 543076
      bogo-ops-per-second-usr-sys-time: 4557.120530
      bogo-ops-per-second-real-time: 36202.803292
      wall-clock-time: 15.000938
      user-time: 119.165870
      system-time: 0.004996
      cpu-usage-per-instance: 99.302847
      max-rss: 2668
      add-matrix-ops-per-sec: 334422.106262
      copy-matrix-ops-per-sec: 435508.595718
      div-matrix-ops-per-sec: 483224.327310
      frobenius-matrix-ops-per-sec: 80764.458974
      hadamard-matrix-ops-per-sec: 369792.333383
      identity-matrix-ops-per-sec: 393645.421599
      mean-matrix-ops-per-sec: 425535.573783
      mult-matrix-ops-per-sec: 537080.626079
      negate-matrix-ops-per-sec: 531397.857760
      prod-matrix-ops-per-sec: 634.100560
      sub-matrix-ops-per-sec: 408020.488324
      square-matrix-ops-per-sec: 678.741518
      trans-matrix-ops-per-sec: 147668.094743
      zero-matrix-ops-per-sec: 897595.216722

...
