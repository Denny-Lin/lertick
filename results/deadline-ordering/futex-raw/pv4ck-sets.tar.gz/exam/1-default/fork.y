---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:07:22
      epoch-secs: 1795338442
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382247
      totalram: 4080812032
      freeram: 2165145600
      sharedram: 3543040
      bufferram: 18702336
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 284185
      bogo-ops-per-second-usr-sys-time: 2823.144213
      bogo-ops-per-second-real-time: 18945.359026
      wall-clock-time: 15.000244
      user-time: 36.344131
      system-time: 64.318456
      cpu-usage-per-instance: 83.884127
      max-rss: 2308

...
