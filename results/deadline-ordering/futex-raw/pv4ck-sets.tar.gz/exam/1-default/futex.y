---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:06:37
      epoch-secs: 1795338397
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382202
      totalram: 4080812032
      freeram: 2317565952
      sharedram: 3543040
      bufferram: 18698240
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 53029774
      bogo-ops-per-second-usr-sys-time: 339084.617894
      bogo-ops-per-second-real-time: 1767626.644204
      wall-clock-time: 30.000551
      user-time: 8.157880
      system-time: 148.233095
      cpu-usage-per-instance: 65.161709
      max-rss: 2204

...
