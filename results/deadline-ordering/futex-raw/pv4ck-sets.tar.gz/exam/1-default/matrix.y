---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:07:07
      epoch-secs: 1795338427
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382232
      totalram: 4080812032
      freeram: 2342359040
      sharedram: 3543040
      bufferram: 18702336
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 544714
      bogo-ops-per-second-usr-sys-time: 4541.900641
      bogo-ops-per-second-real-time: 36311.548548
      wall-clock-time: 15.001123
      user-time: 119.927852
      system-time: 0.002997
      cpu-usage-per-instance: 99.934893
      max-rss: 2664
      add-matrix-ops-per-sec: 329158.711575
      copy-matrix-ops-per-sec: 449834.112947
      div-matrix-ops-per-sec: 474839.248452
      frobenius-matrix-ops-per-sec: 80357.784288
      hadamard-matrix-ops-per-sec: 369566.902767
      identity-matrix-ops-per-sec: 398240.544076
      mean-matrix-ops-per-sec: 415108.035962
      mult-matrix-ops-per-sec: 514932.989591
      negate-matrix-ops-per-sec: 540189.918624
      prod-matrix-ops-per-sec: 637.172500
      sub-matrix-ops-per-sec: 412150.657712
      square-matrix-ops-per-sec: 679.599481
      trans-matrix-ops-per-sec: 145597.436451
      zero-matrix-ops-per-sec: 895321.922717

...
