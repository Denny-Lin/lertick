---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:09:54
      epoch-secs: 1795338594
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382398
      totalram: 4080812032
      freeram: 2301939712
      sharedram: 3543040
      bufferram: 18759680
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 41310253
      bogo-ops-per-second-usr-sys-time: 365342.664469
      bogo-ops-per-second-real-time: 2753905.034316
      wall-clock-time: 15.000609
      user-time: 17.856925
      system-time: 95.215697
      cpu-usage-per-instance: 94.223359
      max-rss: 2444

...
