---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:09:39
      epoch-secs: 1795338579
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382383
      totalram: 4080812032
      freeram: 2313084928
      sharedram: 3543040
      bufferram: 18751488
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 60121372
      bogo-ops-per-second-usr-sys-time: 372132.280821
      bogo-ops-per-second-real-time: 2003987.998629
      wall-clock-time: 30.000864
      user-time: 8.491148
      system-time: 153.067994
      cpu-usage-per-instance: 67.314370
      max-rss: 2176

...
