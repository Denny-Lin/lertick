---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:10:09
      epoch-secs: 1795338609
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382413
      totalram: 4080812032
      freeram: 2319859712
      sharedram: 3543040
      bufferram: 18792448
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 541226
      bogo-ops-per-second-usr-sys-time: 4515.425247
      bogo-ops-per-second-real-time: 36078.839307
      wall-clock-time: 15.001203
      user-time: 119.857583
      system-time: 0.003996
      cpu-usage-per-instance: 99.876638
      max-rss: 2664
      add-matrix-ops-per-sec: 319440.434208
      copy-matrix-ops-per-sec: 456353.133742
      div-matrix-ops-per-sec: 488732.492592
      frobenius-matrix-ops-per-sec: 81650.207074
      hadamard-matrix-ops-per-sec: 367203.288790
      identity-matrix-ops-per-sec: 395766.528385
      mean-matrix-ops-per-sec: 414130.545936
      mult-matrix-ops-per-sec: 519417.718286
      negate-matrix-ops-per-sec: 551786.874250
      prod-matrix-ops-per-sec: 633.052274
      sub-matrix-ops-per-sec: 403040.105384
      square-matrix-ops-per-sec: 675.032061
      trans-matrix-ops-per-sec: 146702.618675
      zero-matrix-ops-per-sec: 899842.171337

...
