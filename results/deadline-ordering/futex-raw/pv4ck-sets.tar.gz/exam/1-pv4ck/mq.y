---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:05:21
      epoch-secs: 1795338321
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382125
      totalram: 4080812032
      freeram: 2338889728
      sharedram: 3543040
      bufferram: 18665472
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 47984869
      bogo-ops-per-second-usr-sys-time: 400229.321977
      bogo-ops-per-second-real-time: 3198879.300024
      wall-clock-time: 15.000525
      user-time: 18.697083
      system-time: 101.196354
      cpu-usage-per-instance: 99.907701
      max-rss: 2568

...
