---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:05:06
      epoch-secs: 1795338306
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382110
      totalram: 4080812032
      freeram: 2323197952
      sharedram: 3543040
      bufferram: 18665472
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 37988894
      bogo-ops-per-second-usr-sys-time: 229983.749622
      bogo-ops-per-second-real-time: 1266237.954451
      wall-clock-time: 30.001386
      user-time: 9.794492
      system-time: 155.386283
      cpu-usage-per-instance: 68.822143
      max-rss: 2156

...
