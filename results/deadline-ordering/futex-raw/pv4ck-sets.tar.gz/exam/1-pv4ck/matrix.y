---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:05:36
      epoch-secs: 1795338336
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382140
      totalram: 4080812032
      freeram: 2347552768
      sharedram: 3543040
      bufferram: 18673664
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 536900
      bogo-ops-per-second-usr-sys-time: 4520.987064
      bogo-ops-per-second-real-time: 35790.682008
      wall-clock-time: 15.001111
      user-time: 118.754254
      system-time: 0.002998
      cpu-usage-per-instance: 98.957046
      max-rss: 2664
      add-matrix-ops-per-sec: 327969.262439
      copy-matrix-ops-per-sec: 453494.388652
      div-matrix-ops-per-sec: 487246.736711
      frobenius-matrix-ops-per-sec: 81238.343151
      hadamard-matrix-ops-per-sec: 343946.204291
      identity-matrix-ops-per-sec: 401014.174850
      mean-matrix-ops-per-sec: 396578.045029
      mult-matrix-ops-per-sec: 512200.211143
      negate-matrix-ops-per-sec: 536703.515095
      prod-matrix-ops-per-sec: 627.130613
      sub-matrix-ops-per-sec: 404175.248412
      square-matrix-ops-per-sec: 670.698081
      trans-matrix-ops-per-sec: 147271.395961
      zero-matrix-ops-per-sec: 888552.394194

...
