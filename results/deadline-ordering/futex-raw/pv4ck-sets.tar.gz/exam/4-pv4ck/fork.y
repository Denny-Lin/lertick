---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:21:00
      epoch-secs: 1795339260
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 383065
      totalram: 4080812032
      freeram: 2282201088
      sharedram: 3543040
      bufferram: 19374080
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 380380
      bogo-ops-per-second-usr-sys-time: 3236.664439
      bogo-ops-per-second-real-time: 25358.079565
      wall-clock-time: 15.000347
      user-time: 41.454610
      system-time: 76.067613
      cpu-usage-per-instance: 97.932918
      max-rss: 2284

...
