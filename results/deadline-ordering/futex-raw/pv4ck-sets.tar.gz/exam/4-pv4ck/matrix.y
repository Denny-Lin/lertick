---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:20:45
      epoch-secs: 1795339245
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 383050
      totalram: 4080812032
      freeram: 2303336448
      sharedram: 3543040
      bufferram: 19374080
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 537186
      bogo-ops-per-second-usr-sys-time: 4520.217143
      bogo-ops-per-second-real-time: 35810.625251
      wall-clock-time: 15.000743
      user-time: 118.831748
      system-time: 0.009003
      cpu-usage-per-instance: 99.029051
      max-rss: 2664
      add-matrix-ops-per-sec: 332988.814449
      copy-matrix-ops-per-sec: 447483.337398
      div-matrix-ops-per-sec: 479055.014483
      frobenius-matrix-ops-per-sec: 80222.157548
      hadamard-matrix-ops-per-sec: 355587.917218
      identity-matrix-ops-per-sec: 393050.977568
      mean-matrix-ops-per-sec: 410642.771417
      mult-matrix-ops-per-sec: 492863.589238
      negate-matrix-ops-per-sec: 537893.273694
      prod-matrix-ops-per-sec: 627.481203
      sub-matrix-ops-per-sec: 394620.777537
      square-matrix-ops-per-sec: 671.224321
      trans-matrix-ops-per-sec: 144658.756155
      zero-matrix-ops-per-sec: 874260.392168

...
