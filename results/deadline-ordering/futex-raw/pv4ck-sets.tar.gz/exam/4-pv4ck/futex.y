---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:20:15
      epoch-secs: 1795339215
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 383020
      totalram: 4080812032
      freeram: 2297327616
      sharedram: 3543040
      bufferram: 19365888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 36018358
      bogo-ops-per-second-usr-sys-time: 219150.913828
      bogo-ops-per-second-real-time: 1200572.800903
      wall-clock-time: 30.000978
      user-time: 9.322842
      system-time: 155.031289
      cpu-usage-per-instance: 68.478656
      max-rss: 2164

...
