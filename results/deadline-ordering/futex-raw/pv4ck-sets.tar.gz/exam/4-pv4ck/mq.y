---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:20:30
      epoch-secs: 1795339230
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 383035
      totalram: 4080812032
      freeram: 2302046208
      sharedram: 3543040
      bufferram: 19374080
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 46907989
      bogo-ops-per-second-usr-sys-time: 391262.909018
      bogo-ops-per-second-real-time: 3127050.617028
      wall-clock-time: 15.000713
      user-time: 18.528394
      system-time: 101.360274
      cpu-usage-per-instance: 99.902474
      max-rss: 2544

...
