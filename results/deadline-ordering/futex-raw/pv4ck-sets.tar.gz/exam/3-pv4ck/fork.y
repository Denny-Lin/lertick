---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:16:27
      epoch-secs: 1795338987
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382792
      totalram: 4080812032
      freeram: 2286034944
      sharedram: 3543040
      bufferram: 18960384
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 388743
      bogo-ops-per-second-usr-sys-time: 3313.708156
      bogo-ops-per-second-real-time: 25915.915156
      wall-clock-time: 15.000165
      user-time: 41.213980
      system-time: 76.099610
      cpu-usage-per-instance: 97.760251
      max-rss: 2312

...
