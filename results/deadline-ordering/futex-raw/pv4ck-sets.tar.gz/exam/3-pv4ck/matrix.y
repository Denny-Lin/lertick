---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:16:12
      epoch-secs: 1795338972
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382777
      totalram: 4080812032
      freeram: 2314493952
      sharedram: 3543040
      bufferram: 18960384
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 540752
      bogo-ops-per-second-usr-sys-time: 4569.148584
      bogo-ops-per-second-real-time: 36048.544470
      wall-clock-time: 15.000661
      user-time: 118.340532
      system-time: 0.007994
      cpu-usage-per-instance: 98.619425
      max-rss: 2564
      add-matrix-ops-per-sec: 321190.239530
      copy-matrix-ops-per-sec: 448862.550702
      div-matrix-ops-per-sec: 494405.726037
      frobenius-matrix-ops-per-sec: 79649.489390
      hadamard-matrix-ops-per-sec: 357464.115776
      identity-matrix-ops-per-sec: 411243.909444
      mean-matrix-ops-per-sec: 428199.757430
      mult-matrix-ops-per-sec: 529634.450082
      negate-matrix-ops-per-sec: 528384.293356
      prod-matrix-ops-per-sec: 632.232794
      sub-matrix-ops-per-sec: 418465.413886
      square-matrix-ops-per-sec: 674.957388
      trans-matrix-ops-per-sec: 147166.825528
      zero-matrix-ops-per-sec: 888399.498032

...
