---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:15:42
      epoch-secs: 1795338942
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382747
      totalram: 4080812032
      freeram: 2299621376
      sharedram: 3543040
      bufferram: 18952192
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 39018720
      bogo-ops-per-second-usr-sys-time: 235065.882146
      bogo-ops-per-second-real-time: 1300577.155690
      wall-clock-time: 30.001081
      user-time: 9.534611
      system-time: 156.455960
      cpu-usage-per-instance: 69.160247
      max-rss: 2164

...
