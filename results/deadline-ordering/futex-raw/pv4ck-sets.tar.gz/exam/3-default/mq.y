---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:14:27
      epoch-secs: 1795338867
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382671
      totalram: 4080812032
      freeram: 2299285504
      sharedram: 3543040
      bufferram: 18886656
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 34462214
      bogo-ops-per-second-usr-sys-time: 351787.441593
      bogo-ops-per-second-real-time: 2297397.288535
      wall-clock-time: 15.000546
      user-time: 15.273743
      system-time: 82.689430
      cpu-usage-per-instance: 81.633005
      max-rss: 2588

...
