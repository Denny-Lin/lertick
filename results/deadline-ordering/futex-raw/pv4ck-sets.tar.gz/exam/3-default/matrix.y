---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:14:42
      epoch-secs: 1795338882
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382686
      totalram: 4080812032
      freeram: 2311618560
      sharedram: 3543040
      bufferram: 18890752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 542732
      bogo-ops-per-second-usr-sys-time: 4523.145292
      bogo-ops-per-second-real-time: 36179.852561
      wall-clock-time: 15.000946
      user-time: 119.987955
      system-time: 0.002000
      cpu-usage-per-instance: 99.985326
      max-rss: 2664
      add-matrix-ops-per-sec: 329477.206973
      copy-matrix-ops-per-sec: 419721.967330
      div-matrix-ops-per-sec: 480149.266086
      frobenius-matrix-ops-per-sec: 79910.948668
      hadamard-matrix-ops-per-sec: 360998.202579
      identity-matrix-ops-per-sec: 403034.504897
      mean-matrix-ops-per-sec: 423313.313234
      mult-matrix-ops-per-sec: 535942.708721
      negate-matrix-ops-per-sec: 541605.376663
      prod-matrix-ops-per-sec: 634.359389
      sub-matrix-ops-per-sec: 399237.371853
      square-matrix-ops-per-sec: 677.760231
      trans-matrix-ops-per-sec: 146072.356484
      zero-matrix-ops-per-sec: 877930.890750

...
