---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:14:57
      epoch-secs: 1795338897
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382701
      totalram: 4080812032
      freeram: 2111184896
      sharedram: 3543040
      bufferram: 18898944
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 277211
      bogo-ops-per-second-usr-sys-time: 2794.366430
      bogo-ops-per-second-real-time: 18480.358561
      wall-clock-time: 15.000304
      user-time: 35.707571
      system-time: 63.495954
      cpu-usage-per-instance: 82.667928
      max-rss: 2308

...
