---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:11:09
      epoch-secs: 1795338669
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382474
      totalram: 4080812032
      freeram: 2300014592
      sharedram: 3543040
      bufferram: 18821120
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 37986548
      bogo-ops-per-second-usr-sys-time: 229469.273546
      bogo-ops-per-second-real-time: 1266175.819846
      wall-clock-time: 30.001006
      user-time: 9.811547
      system-time: 155.729344
      cpu-usage-per-instance: 68.973059
      max-rss: 2152

...
