---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:11:39
      epoch-secs: 1795338699
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382504
      totalram: 4080812032
      freeram: 2312011776
      sharedram: 3543040
      bufferram: 18829312
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 538130
      bogo-ops-per-second-usr-sys-time: 4557.710771
      bogo-ops-per-second-real-time: 35873.414920
      wall-clock-time: 15.000802
      user-time: 118.061236
      system-time: 0.009003
      cpu-usage-per-instance: 98.386604
      max-rss: 2664
      add-matrix-ops-per-sec: 320695.105217
      copy-matrix-ops-per-sec: 460927.881681
      div-matrix-ops-per-sec: 490883.806378
      frobenius-matrix-ops-per-sec: 79063.991344
      hadamard-matrix-ops-per-sec: 366913.096885
      identity-matrix-ops-per-sec: 399749.810201
      mean-matrix-ops-per-sec: 408067.380430
      mult-matrix-ops-per-sec: 553976.457007
      negate-matrix-ops-per-sec: 533078.990751
      prod-matrix-ops-per-sec: 628.266875
      sub-matrix-ops-per-sec: 415587.068042
      square-matrix-ops-per-sec: 672.582057
      trans-matrix-ops-per-sec: 145696.495002
      zero-matrix-ops-per-sec: 903105.697732

...
