---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:11:24
      epoch-secs: 1795338684
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382489
      totalram: 4080812032
      freeram: 2305343488
      sharedram: 3543040
      bufferram: 18821120
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 48156818
      bogo-ops-per-second-usr-sys-time: 401617.243368
      bogo-ops-per-second-real-time: 3210362.039919
      wall-clock-time: 15.000432
      user-time: 18.853263
      system-time: 101.053984
      cpu-usage-per-instance: 99.919827
      max-rss: 2592

...
