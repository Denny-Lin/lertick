---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:11:54
      epoch-secs: 1795338714
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382519
      totalram: 4080812032
      freeram: 2293284864
      sharedram: 3543040
      bufferram: 18829312
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 383756
      bogo-ops-per-second-usr-sys-time: 3265.574592
      bogo-ops-per-second-real-time: 25583.218941
      wall-clock-time: 15.000302
      user-time: 41.364287
      system-time: 76.151326
      cpu-usage-per-instance: 97.927709
      max-rss: 2308

...
