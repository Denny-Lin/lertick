---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:04:19
      epoch-secs: 1795338259
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382063
      totalram: 4080812032
      freeram: 2517655552
      sharedram: 3543040
      bufferram: 17711104
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 404112
      bogo-ops-per-second-usr-sys-time: 3382.039335
      bogo-ops-per-second-real-time: 26940.353649
      wall-clock-time: 15.000249
      user-time: 43.275513
      system-time: 76.212157
      cpu-usage-per-instance: 99.571409
      max-rss: 2280

...
