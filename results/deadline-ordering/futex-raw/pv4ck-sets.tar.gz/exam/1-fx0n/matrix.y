---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:04:04
      epoch-secs: 1795338244
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382048
      totalram: 4080812032
      freeram: 2532524032
      sharedram: 3543040
      bufferram: 17711104
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 541822
      bogo-ops-per-second-usr-sys-time: 4548.780054
      bogo-ops-per-second-real-time: 36117.857654
      wall-clock-time: 15.001499
      user-time: 119.102695
      system-time: 0.011000
      cpu-usage-per-instance: 99.251495
      max-rss: 2468
      add-matrix-ops-per-sec: 314535.824295
      copy-matrix-ops-per-sec: 442371.413827
      div-matrix-ops-per-sec: 470662.341741
      frobenius-matrix-ops-per-sec: 79628.057686
      hadamard-matrix-ops-per-sec: 378390.726055
      identity-matrix-ops-per-sec: 392294.099079
      mean-matrix-ops-per-sec: 416538.216561
      mult-matrix-ops-per-sec: 536499.817967
      negate-matrix-ops-per-sec: 537991.747464
      prod-matrix-ops-per-sec: 633.673873
      sub-matrix-ops-per-sec: 401340.634897
      square-matrix-ops-per-sec: 676.187600
      trans-matrix-ops-per-sec: 144691.309683
      zero-matrix-ops-per-sec: 869934.600860

...
