---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:03:49
      epoch-secs: 1795338229
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382033
      totalram: 4080812032
      freeram: 2530934784
      sharedram: 3543040
      bufferram: 17711104
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 41229444
      bogo-ops-per-second-usr-sys-time: 343778.948373
      bogo-ops-per-second-real-time: 2748514.890258
      wall-clock-time: 15.000626
      user-time: 16.806736
      system-time: 103.123365
      cpu-usage-per-instance: 99.937580
      max-rss: 2548

...
