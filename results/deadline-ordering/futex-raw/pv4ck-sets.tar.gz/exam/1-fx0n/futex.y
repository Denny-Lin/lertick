---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:03:34
      epoch-secs: 1795338214
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382018
      totalram: 4080812032
      freeram: 2519867392
      sharedram: 3543040
      bufferram: 17702912
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 93614
      bogo-ops-per-second-usr-sys-time: 778.556485
      bogo-ops-per-second-real-time: 3120.382947
      wall-clock-time: 30.000805
      user-time: 3.927448
      system-time: 116.313025
      cpu-usage-per-instance: 50.098853
      max-rss: 2176

...
