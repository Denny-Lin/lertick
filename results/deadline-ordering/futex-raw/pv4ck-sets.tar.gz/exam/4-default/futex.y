---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:17:14
      epoch-secs: 1795339034
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382838
      totalram: 4080812032
      freeram: 2298900480
      sharedram: 3543040
      bufferram: 19259392
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 57492922
      bogo-ops-per-second-usr-sys-time: 358329.348428
      bogo-ops-per-second-real-time: 1916402.669786
      wall-clock-time: 30.000439
      user-time: 8.747715
      system-time: 151.699433
      cpu-usage-per-instance: 66.851999
      max-rss: 2176

...
