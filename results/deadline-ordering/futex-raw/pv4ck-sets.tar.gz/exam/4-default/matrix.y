---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:17:44
      epoch-secs: 1795339064
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382868
      totalram: 4080812032
      freeram: 2320936960
      sharedram: 3543040
      bufferram: 19267584
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 544784
      bogo-ops-per-second-usr-sys-time: 4539.857473
      bogo-ops-per-second-real-time: 36316.845021
      wall-clock-time: 15.000863
      user-time: 119.997244
      system-time: 0.002999
      cpu-usage-per-instance: 99.994453
      max-rss: 2664
      add-matrix-ops-per-sec: 332186.234371
      copy-matrix-ops-per-sec: 441256.236398
      div-matrix-ops-per-sec: 482041.094653
      frobenius-matrix-ops-per-sec: 80693.775393
      hadamard-matrix-ops-per-sec: 356180.511387
      identity-matrix-ops-per-sec: 392277.067749
      mean-matrix-ops-per-sec: 415548.327511
      mult-matrix-ops-per-sec: 527838.324291
      negate-matrix-ops-per-sec: 542130.597137
      prod-matrix-ops-per-sec: 637.225344
      sub-matrix-ops-per-sec: 416315.111466
      square-matrix-ops-per-sec: 679.668842
      trans-matrix-ops-per-sec: 149018.432250
      zero-matrix-ops-per-sec: 908316.678306

...
