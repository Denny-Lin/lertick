---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 09:17:29
      epoch-secs: 1795339049
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 382853
      totalram: 4080812032
      freeram: 2309668864
      sharedram: 3543040
      bufferram: 19259392
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 43298998
      bogo-ops-per-second-usr-sys-time: 368177.159044
      bogo-ops-per-second-real-time: 2886516.422520
      wall-clock-time: 15.000434
      user-time: 18.738827
      system-time: 98.864878
      cpu-usage-per-instance: 98.000254
      max-rss: 2536

...
