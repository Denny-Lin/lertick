---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:21
      time-hh-mm-ss: 23:59:59
      epoch-secs: 1795305599
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349403
      totalram: 4080812032
      freeram: 2283266048
      sharedram: 3543040
      bufferram: 24997888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 13494894
      bogo-ops-per-second-usr-sys-time: 160513.387100
      bogo-ops-per-second-real-time: 843391.636077
      wall-clock-time: 16.000744
      user-time: 4.157949
      system-time: 79.915375
      cpu-usage-per-instance: 65.679229
      max-rss: 2152

...
