---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:21
      time-hh-mm-ss: 23:57:15
      epoch-secs: 1795305435
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349239
      totalram: 4080812032
      freeram: 2276274176
      sharedram: 3543040
      bufferram: 24915968
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 9212344
      bogo-ops-per-second-usr-sys-time: 112399.710461
      bogo-ops-per-second-real-time: 575723.102967
      wall-clock-time: 16.001345
      user-time: 3.764408
      system-time: 78.196159
      cpu-usage-per-instance: 64.026311
      max-rss: 2156

...
