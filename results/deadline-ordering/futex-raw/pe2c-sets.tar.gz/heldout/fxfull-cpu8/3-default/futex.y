---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:03:39
      epoch-secs: 1795305819
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349624
      totalram: 4080812032
      freeram: 2276921344
      sharedram: 3543040
      bufferram: 25268224
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28882224
      bogo-ops-per-second-usr-sys-time: 351392.238295
      bogo-ops-per-second-real-time: 1805086.814732
      wall-clock-time: 16.000463
      user-time: 4.952886
      system-time: 77.240802
      cpu-usage-per-instance: 64.211962
      max-rss: 2180

...
