---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:21
      time-hh-mm-ss: 23:58:12
      epoch-secs: 1795305492
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349296
      totalram: 4080812032
      freeram: 2284482560
      sharedram: 3543040
      bufferram: 24936448
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 32561212
      bogo-ops-per-second-usr-sys-time: 377781.737996
      bogo-ops-per-second-real-time: 2035030.794193
      wall-clock-time: 16.000353
      user-time: 5.014517
      system-time: 81.176023
      cpu-usage-per-instance: 67.334872
      max-rss: 2176

...
