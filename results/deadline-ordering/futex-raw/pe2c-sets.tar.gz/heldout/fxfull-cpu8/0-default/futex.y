---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:21
      time-hh-mm-ss: 23:55:29
      epoch-secs: 1795305329
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349133
      totalram: 4080812032
      freeram: 2265690112
      sharedram: 3543040
      bufferram: 24887296
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 31431782
      bogo-ops-per-second-usr-sys-time: 364966.845867
      bogo-ops-per-second-real-time: 1964432.312679
      wall-clock-time: 16.000440
      user-time: 4.301986
      system-time: 81.820308
      cpu-usage-per-instance: 67.281191
      max-rss: 2176

...
