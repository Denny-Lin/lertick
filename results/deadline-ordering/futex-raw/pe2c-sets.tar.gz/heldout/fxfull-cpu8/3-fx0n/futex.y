---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:04:33
      epoch-secs: 1795305873
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349678
      totalram: 4080812032
      freeram: 2270871552
      sharedram: 3543040
      bufferram: 25329664
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 51064
      bogo-ops-per-second-usr-sys-time: 796.091283
      bogo-ops-per-second-real-time: 3191.364046
      wall-clock-time: 16.000682
      user-time: 2.078461
      system-time: 62.064937
      cpu-usage-per-instance: 50.109895
      max-rss: 2152

...
