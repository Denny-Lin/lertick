---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:21
      time-hh-mm-ss: 23:59:06
      epoch-secs: 1795305546
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349350
      totalram: 4080812032
      freeram: 2275278848
      sharedram: 3543040
      bufferram: 24985600
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 103272
      bogo-ops-per-second-usr-sys-time: 1608.091732
      bogo-ops-per-second-real-time: 6454.279865
      wall-clock-time: 16.000546
      user-time: 2.701670
      system-time: 61.518547
      cpu-usage-per-instance: 50.170333
      max-rss: 2152

...
