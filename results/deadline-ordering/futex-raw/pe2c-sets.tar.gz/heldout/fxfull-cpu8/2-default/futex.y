---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:00:56
      epoch-secs: 1795305656
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349460
      totalram: 4080812032
      freeram: 2276831232
      sharedram: 3543040
      bufferram: 25219072
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 30964674
      bogo-ops-per-second-usr-sys-time: 359680.364904
      bogo-ops-per-second-real-time: 1935231.974198
      wall-clock-time: 16.000497
      user-time: 4.446457
      system-time: 81.642963
      cpu-usage-per-instance: 67.255269
      max-rss: 2180

...
