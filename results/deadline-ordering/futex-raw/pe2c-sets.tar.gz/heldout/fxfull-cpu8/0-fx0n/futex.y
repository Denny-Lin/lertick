---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:21
      time-hh-mm-ss: 23:56:22
      epoch-secs: 1795305382
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349186
      totalram: 4080812032
      freeram: 2277765120
      sharedram: 3543040
      bufferram: 24903680
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 56108
      bogo-ops-per-second-usr-sys-time: 873.427174
      bogo-ops-per-second-real-time: 3506.535220
      wall-clock-time: 16.000980
      user-time: 1.993464
      system-time: 62.245435
      cpu-usage-per-instance: 50.183566
      max-rss: 2152

...
