---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:10:03
      epoch-secs: 1795306203
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 350008
      totalram: 4080812032
      freeram: 2254721024
      sharedram: 3522560
      bufferram: 25583616
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 38666
      bogo-ops-per-second-usr-sys-time: 1206.184263
      bogo-ops-per-second-real-time: 2416.582580
      wall-clock-time: 16.000281
      user-time: 7.645105
      system-time: 24.411357
      cpu-usage-per-instance: 50.087343
      max-rss: 2204

...
