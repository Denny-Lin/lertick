---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:13:40
      epoch-secs: 1795306420
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 350224
      totalram: 4080812032
      freeram: 2260525056
      sharedram: 3522560
      bufferram: 25636864
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19018664
      bogo-ops-per-second-usr-sys-time: 425020.027291
      bogo-ops-per-second-real-time: 1188616.309291
      wall-clock-time: 16.000676
      user-time: 3.474779
      system-time: 41.272910
      cpu-usage-per-instance: 69.915312
      max-rss: 2152

...
