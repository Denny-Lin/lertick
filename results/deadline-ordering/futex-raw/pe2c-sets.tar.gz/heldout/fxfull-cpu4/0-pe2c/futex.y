---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:08:13
      epoch-secs: 1795306093
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349897
      totalram: 4080812032
      freeram: 2263519232
      sharedram: 3522560
      bufferram: 25538560
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19683590
      bogo-ops-per-second-usr-sys-time: 438260.619497
      bogo-ops-per-second-real-time: 1230247.491799
      wall-clock-time: 15.999699
      user-time: 3.662542
      system-time: 41.250437
      cpu-usage-per-instance: 70.177848
      max-rss: 2180

...
