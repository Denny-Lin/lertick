---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:15:31
      epoch-secs: 1795306531
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 350335
      totalram: 4080812032
      freeram: 2263191552
      sharedram: 3522560
      bufferram: 25681920
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 24246
      bogo-ops-per-second-usr-sys-time: 756.715806
      bogo-ops-per-second-real-time: 1515.350353
      wall-clock-time: 16.000260
      user-time: 7.430534
      system-time: 24.610557
      cpu-usage-per-instance: 50.063390
      max-rss: 2176

...
