---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:06:25
      epoch-secs: 1795305985
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349789
      totalram: 4080812032
      freeram: 2270224384
      sharedram: 3522560
      bufferram: 25374720
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28704548
      bogo-ops-per-second-usr-sys-time: 664241.343449
      bogo-ops-per-second-real-time: 1794006.467959
      wall-clock-time: 16.000248
      user-time: 5.853666
      system-time: 37.360368
      cpu-usage-per-instance: 67.520882
      max-rss: 2180

...
