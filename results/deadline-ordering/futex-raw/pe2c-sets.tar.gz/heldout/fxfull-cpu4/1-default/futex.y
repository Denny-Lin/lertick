---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:09:10
      epoch-secs: 1795306150
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349954
      totalram: 4080812032
      freeram: 2273898496
      sharedram: 3522560
      bufferram: 25567232
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28851486
      bogo-ops-per-second-usr-sys-time: 667823.055958
      bogo-ops-per-second-real-time: 1803194.135632
      wall-clock-time: 16.000211
      user-time: 5.834177
      system-time: 37.368114
      cpu-usage-per-instance: 67.502691
      max-rss: 2176

...
