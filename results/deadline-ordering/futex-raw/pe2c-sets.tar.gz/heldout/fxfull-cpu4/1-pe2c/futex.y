---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:10:57
      epoch-secs: 1795306257
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 350061
      totalram: 4080812032
      freeram: 2265542656
      sharedram: 3522560
      bufferram: 25600000
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 18124200
      bogo-ops-per-second-usr-sys-time: 406532.586264
      bogo-ops-per-second-real-time: 1132741.654230
      wall-clock-time: 16.000294
      user-time: 3.554299
      system-time: 41.028105
      cpu-usage-per-instance: 69.658724
      max-rss: 2176

...
