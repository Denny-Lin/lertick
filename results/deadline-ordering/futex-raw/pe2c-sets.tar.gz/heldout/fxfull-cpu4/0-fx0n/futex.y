---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 00:07:19
      epoch-secs: 1795306039
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 349844
      totalram: 4080812032
      freeram: 2263998464
      sharedram: 3522560
      bufferram: 25518080
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23424
      bogo-ops-per-second-usr-sys-time: 731.197830
      bogo-ops-per-second-real-time: 1463.988711
      wall-clock-time: 16.000123
      user-time: 8.145400
      system-time: 23.889706
      cpu-usage-per-instance: 50.054467
      max-rss: 2152

...
