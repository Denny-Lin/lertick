---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:05:31
      epoch-secs: 1795313131
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356935
      totalram: 4080812032
      freeram: 2254643200
      sharedram: 3543040
      bufferram: 27582464
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 49252
      bogo-ops-per-second-usr-sys-time: 767.571073
      bogo-ops-per-second-real-time: 3078.025577
      wall-clock-time: 16.001167
      user-time: 2.131531
      system-time: 62.034514
      cpu-usage-per-instance: 50.126068
      max-rss: 2152

...
