---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 01:55:57
      epoch-secs: 1795312557
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356361
      totalram: 4080812032
      freeram: 2253393920
      sharedram: 3543040
      bufferram: 27381760
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28451308
      bogo-ops-per-second-usr-sys-time: 349195.206488
      bogo-ops-per-second-real-time: 1778154.303364
      wall-clock-time: 16.000472
      user-time: 5.184935
      system-time: 76.291865
      cpu-usage-per-instance: 63.651873
      max-rss: 2176

...
