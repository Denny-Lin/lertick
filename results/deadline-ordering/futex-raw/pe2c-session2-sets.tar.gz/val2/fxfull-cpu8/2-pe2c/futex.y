---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:03:39
      epoch-secs: 1795313019
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356823
      totalram: 4080812032
      freeram: 2226266112
      sharedram: 3543040
      bufferram: 27557888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 14709680
      bogo-ops-per-second-usr-sys-time: 173561.752963
      bogo-ops-per-second-real-time: 919310.614190
      wall-clock-time: 16.000773
      user-time: 4.335210
      system-time: 80.416642
      cpu-usage-per-instance: 66.209188
      max-rss: 2164

...
