---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 01:56:52
      epoch-secs: 1795312612
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356416
      totalram: 4080812032
      freeram: 2263678976
      sharedram: 3543040
      bufferram: 27398144
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 49496
      bogo-ops-per-second-usr-sys-time: 771.620516
      bogo-ops-per-second-real-time: 3093.352953
      wall-clock-time: 16.000761
      user-time: 2.508380
      system-time: 61.637141
      cpu-usage-per-instance: 50.111306
      max-rss: 2176

...
