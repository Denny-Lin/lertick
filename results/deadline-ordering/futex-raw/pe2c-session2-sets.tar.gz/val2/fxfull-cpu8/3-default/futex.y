---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:04:37
      epoch-secs: 1795313077
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356881
      totalram: 4080812032
      freeram: 2246512640
      sharedram: 3543040
      bufferram: 27570176
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 29483666
      bogo-ops-per-second-usr-sys-time: 349959.070088
      bogo-ops-per-second-real-time: 1842635.217245
      wall-clock-time: 16.000815
      user-time: 4.645501
      system-time: 79.603397
      cpu-usage-per-instance: 65.816097
      max-rss: 2176

...
