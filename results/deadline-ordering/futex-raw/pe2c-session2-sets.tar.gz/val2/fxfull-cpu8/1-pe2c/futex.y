---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:00:31
      epoch-secs: 1795312831
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356635
      totalram: 4080812032
      freeram: 2245599232
      sharedram: 3543040
      bufferram: 27508736
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 11640946
      bogo-ops-per-second-usr-sys-time: 140067.379689
      bogo-ops-per-second-real-time: 727531.495193
      wall-clock-time: 16.000608
      user-time: 3.676189
      system-time: 79.433426
      cpu-usage-per-instance: 64.926921
      max-rss: 2152

...
