---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 01:57:46
      epoch-secs: 1795312666
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356470
      totalram: 4080812032
      freeram: 2237870080
      sharedram: 3543040
      bufferram: 27443200
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 13249466
      bogo-ops-per-second-usr-sys-time: 157651.296521
      bogo-ops-per-second-real-time: 828054.112995
      wall-clock-time: 16.000725
      user-time: 4.109582
      system-time: 79.933279
      cpu-usage-per-instance: 65.655511
      max-rss: 2164

...
