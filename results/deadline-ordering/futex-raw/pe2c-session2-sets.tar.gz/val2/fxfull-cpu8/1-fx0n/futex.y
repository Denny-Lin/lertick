---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 01:59:36
      epoch-secs: 1795312776
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356581
      totalram: 4080812032
      freeram: 2259795968
      sharedram: 3543040
      bufferram: 27484160
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 50482
      bogo-ops-per-second-usr-sys-time: 786.915277
      bogo-ops-per-second-real-time: 3154.941717
      wall-clock-time: 16.000930
      user-time: 2.585310
      system-time: 61.566450
      cpu-usage-per-instance: 50.115651
      max-rss: 2152

...
