---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 01:58:43
      epoch-secs: 1795312723
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356528
      totalram: 4080812032
      freeram: 2264612864
      sharedram: 3543040
      bufferram: 27463680
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 32755938
      bogo-ops-per-second-usr-sys-time: 379986.347100
      bogo-ops-per-second-real-time: 2047199.443731
      wall-clock-time: 16.000365
      user-time: 4.908709
      system-time: 81.294225
      cpu-usage-per-instance: 67.344507
      max-rss: 2152

...
