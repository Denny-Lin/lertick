---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:02:23
      epoch-secs: 1795312943
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 356747
      totalram: 4080812032
      freeram: 2262093824
      sharedram: 3543040
      bufferram: 27529216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 60012
      bogo-ops-per-second-usr-sys-time: 924.474776
      bogo-ops-per-second-real-time: 3744.006970
      wall-clock-time: 16.028816
      user-time: 4.575740
      system-time: 60.338957
      cpu-usage-per-instance: 50.623433
      max-rss: 2152

...
