---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:15:39
      epoch-secs: 1795313739
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357543
      totalram: 4080812032
      freeram: 2246496256
      sharedram: 3522560
      bufferram: 27799552
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28830030
      bogo-ops-per-second-usr-sys-time: 667286.195233
      bogo-ops-per-second-real-time: 1801851.347669
      wall-clock-time: 16.000227
      user-time: 5.877198
      system-time: 37.327697
      cpu-usage-per-instance: 67.506692
      max-rss: 2180

...
