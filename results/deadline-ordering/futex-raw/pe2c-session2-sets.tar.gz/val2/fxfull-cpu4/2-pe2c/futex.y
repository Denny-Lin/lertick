---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:14:41
      epoch-secs: 1795313681
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357485
      totalram: 4080812032
      freeram: 2245435392
      sharedram: 3522560
      bufferram: 27787264
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 18166258
      bogo-ops-per-second-usr-sys-time: 407677.852267
      bogo-ops-per-second-real-time: 1135374.726839
      wall-clock-time: 16.000231
      user-time: 3.371553
      system-time: 41.188773
      cpu-usage-per-instance: 69.624504
      max-rss: 2152

...
