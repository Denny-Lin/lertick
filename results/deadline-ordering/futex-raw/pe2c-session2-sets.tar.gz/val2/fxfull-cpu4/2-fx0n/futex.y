---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:13:47
      epoch-secs: 1795313627
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357431
      totalram: 4080812032
      freeram: 2245349376
      sharedram: 3522560
      bufferram: 27770880
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23124
      bogo-ops-per-second-usr-sys-time: 721.672055
      bogo-ops-per-second-real-time: 1445.203818
      wall-clock-time: 16.000511
      user-time: 7.377022
      system-time: 24.665233
      cpu-usage-per-instance: 50.064424
      max-rss: 2180

...
