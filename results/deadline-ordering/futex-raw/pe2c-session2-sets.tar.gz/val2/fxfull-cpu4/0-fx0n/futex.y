---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:08:16
      epoch-secs: 1795313296
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357100
      totalram: 4080812032
      freeram: 2247827456
      sharedram: 3522560
      bufferram: 27648000
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23058
      bogo-ops-per-second-usr-sys-time: 719.698098
      bogo-ops-per-second-real-time: 1441.074741
      wall-clock-time: 16.000558
      user-time: 7.355382
      system-time: 24.683052
      cpu-usage-per-instance: 50.058307
      max-rss: 2176

...
