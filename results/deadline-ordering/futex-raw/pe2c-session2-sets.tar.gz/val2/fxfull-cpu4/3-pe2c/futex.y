---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:17:27
      epoch-secs: 1795313847
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357651
      totalram: 4080812032
      freeram: 2247675904
      sharedram: 3522560
      bufferram: 27832320
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19238112
      bogo-ops-per-second-usr-sys-time: 429290.069084
      bogo-ops-per-second-real-time: 1202361.834881
      wall-clock-time: 16.000268
      user-time: 3.547504
      system-time: 41.266279
      cpu-usage-per-instance: 70.020362
      max-rss: 2152

...
