---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:07:23
      epoch-secs: 1795313243
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357047
      totalram: 4080812032
      freeram: 2247307264
      sharedram: 3522560
      bufferram: 27619328
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 11250284
      bogo-ops-per-second-usr-sys-time: 277492.641759
      bogo-ops-per-second-real-time: 703135.140694
      wall-clock-time: 16.000173
      user-time: 6.662684
      system-time: 33.879955
      cpu-usage-per-instance: 63.347188
      max-rss: 2180

...
