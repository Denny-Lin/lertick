---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:16:33
      epoch-secs: 1795313793
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357597
      totalram: 4080812032
      freeram: 2244993024
      sharedram: 3522560
      bufferram: 27811840
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 49720
      bogo-ops-per-second-usr-sys-time: 1549.619199
      bogo-ops-per-second-real-time: 3107.478433
      wall-clock-time: 16.000111
      user-time: 8.074223
      system-time: 24.011079
      cpu-usage-per-instance: 50.132936
      max-rss: 2152

...
