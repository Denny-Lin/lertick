---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 02:11:55
      epoch-secs: 1795313515
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 357319
      totalram: 4080812032
      freeram: 2259275776
      sharedram: 3522560
      bufferram: 27713536
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 17896360
      bogo-ops-per-second-usr-sys-time: 401611.061694
      bogo-ops-per-second-real-time: 1118494.837159
      wall-clock-time: 16.000396
      user-time: 3.446886
      system-time: 41.114536
      cpu-usage-per-instance: 69.625500
      max-rss: 2152

...
