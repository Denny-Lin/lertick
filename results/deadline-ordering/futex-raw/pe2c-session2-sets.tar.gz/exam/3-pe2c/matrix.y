---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:16:26
      epoch-secs: 1795317386
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361191
      totalram: 4080812032
      freeram: 2265116672
      sharedram: 3543040
      bufferram: 32894976
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 537884
      bogo-ops-per-second-usr-sys-time: 4569.004084
      bogo-ops-per-second-real-time: 35856.759629
      wall-clock-time: 15.000909
      user-time: 117.711562
      system-time: 0.012999
      cpu-usage-per-instance: 98.097854
      max-rss: 2664
      add-matrix-ops-per-sec: 313603.913162
      copy-matrix-ops-per-sec: 445521.743709
      div-matrix-ops-per-sec: 485792.628608
      frobenius-matrix-ops-per-sec: 80065.605240
      hadamard-matrix-ops-per-sec: 381919.447366
      identity-matrix-ops-per-sec: 405999.624611
      mean-matrix-ops-per-sec: 423813.305349
      mult-matrix-ops-per-sec: 520752.276686
      negate-matrix-ops-per-sec: 529369.165327
      prod-matrix-ops-per-sec: 628.074454
      sub-matrix-ops-per-sec: 415562.181474
      square-matrix-ops-per-sec: 672.081956
      trans-matrix-ops-per-sec: 146497.338765
      zero-matrix-ops-per-sec: 912678.647351

...
