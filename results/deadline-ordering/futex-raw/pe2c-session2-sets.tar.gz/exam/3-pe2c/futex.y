---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:15:56
      epoch-secs: 1795317356
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361161
      totalram: 4080812032
      freeram: 2242088960
      sharedram: 3543040
      bufferram: 32886784
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23996428
      bogo-ops-per-second-usr-sys-time: 152552.659004
      bogo-ops-per-second-real-time: 799847.349744
      wall-clock-time: 30.001260
      user-time: 7.515224
      system-time: 149.784086
      cpu-usage-per-instance: 65.538627
      max-rss: 2176

...
