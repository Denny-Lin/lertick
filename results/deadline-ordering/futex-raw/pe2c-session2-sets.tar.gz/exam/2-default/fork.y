---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:15:11
      epoch-secs: 1795317311
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361115
      totalram: 4080812032
      freeram: 2206027776
      sharedram: 3543040
      bufferram: 32870400
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 244840
      bogo-ops-per-second-usr-sys-time: 2592.320556
      bogo-ops-per-second-real-time: 16322.256694
      wall-clock-time: 15.000377
      user-time: 33.928841
      system-time: 60.519355
      cpu-usage-per-instance: 78.704853
      max-rss: 2308

...
