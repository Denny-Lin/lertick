---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:14:26
      epoch-secs: 1795317266
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361070
      totalram: 4080812032
      freeram: 2262708224
      sharedram: 3543040
      bufferram: 32862208
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 60785052
      bogo-ops-per-second-usr-sys-time: 376449.672945
      bogo-ops-per-second-real-time: 2026132.489960
      wall-clock-time: 30.000532
      user-time: 9.081249
      system-time: 152.388016
      cpu-usage-per-instance: 67.277668
      max-rss: 2180

...
