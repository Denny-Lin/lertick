---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:14:56
      epoch-secs: 1795317296
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361100
      totalram: 4080812032
      freeram: 2274058240
      sharedram: 3543040
      bufferram: 32870400
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 527928
      bogo-ops-per-second-usr-sys-time: 4401.500396
      bogo-ops-per-second-real-time: 35193.151131
      wall-clock-time: 15.000873
      user-time: 119.936735
      system-time: 0.006001
      cpu-usage-per-instance: 99.946461
      max-rss: 2664
      add-matrix-ops-per-sec: 314278.407436
      copy-matrix-ops-per-sec: 427599.243981
      div-matrix-ops-per-sec: 482322.110232
      frobenius-matrix-ops-per-sec: 78779.354367
      hadamard-matrix-ops-per-sec: 355056.134312
      identity-matrix-ops-per-sec: 377068.942125
      mean-matrix-ops-per-sec: 398733.878528
      mult-matrix-ops-per-sec: 505385.630472
      negate-matrix-ops-per-sec: 516156.536806
      prod-matrix-ops-per-sec: 616.548799
      sub-matrix-ops-per-sec: 391862.784305
      square-matrix-ops-per-sec: 659.812427
      trans-matrix-ops-per-sec: 142546.493942
      zero-matrix-ops-per-sec: 845102.159562

...
