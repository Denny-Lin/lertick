---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:08:36
      epoch-secs: 1795316916
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360720
      totalram: 4080812032
      freeram: 2272550912
      sharedram: 3543040
      bufferram: 32649216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 23496649
      bogo-ops-per-second-usr-sys-time: 196260.546353
      bogo-ops-per-second-real-time: 1566356.162937
      wall-clock-time: 15.000834
      user-time: 8.765676
      system-time: 110.956038
      cpu-usage-per-instance: 99.762547
      max-rss: 2544

...
