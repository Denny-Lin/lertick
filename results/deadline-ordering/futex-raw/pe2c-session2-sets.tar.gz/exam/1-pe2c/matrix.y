---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:08:51
      epoch-secs: 1795316931
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360735
      totalram: 4080812032
      freeram: 2283204608
      sharedram: 3543040
      bufferram: 32657408
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 540894
      bogo-ops-per-second-usr-sys-time: 4547.084281
      bogo-ops-per-second-real-time: 36056.295509
      wall-clock-time: 15.001375
      user-time: 118.948029
      system-time: 0.006001
      cpu-usage-per-instance: 99.119274
      max-rss: 2664
      add-matrix-ops-per-sec: 327953.772309
      copy-matrix-ops-per-sec: 450252.630998
      div-matrix-ops-per-sec: 472005.643115
      frobenius-matrix-ops-per-sec: 80711.997178
      hadamard-matrix-ops-per-sec: 396984.004957
      identity-matrix-ops-per-sec: 404539.134800
      mean-matrix-ops-per-sec: 432694.779136
      mult-matrix-ops-per-sec: 537191.399930
      negate-matrix-ops-per-sec: 527560.625319
      prod-matrix-ops-per-sec: 632.624771
      sub-matrix-ops-per-sec: 426782.430280
      square-matrix-ops-per-sec: 674.559773
      trans-matrix-ops-per-sec: 146203.197634
      zero-matrix-ops-per-sec: 853010.678666

...
