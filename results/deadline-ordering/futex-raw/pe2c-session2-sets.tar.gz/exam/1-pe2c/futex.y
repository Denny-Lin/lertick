---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:08:21
      epoch-secs: 1795316901
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360705
      totalram: 4080812032
      freeram: 2259804160
      sharedram: 3543040
      bufferram: 32649216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 27981318
      bogo-ops-per-second-usr-sys-time: 175636.090625
      bogo-ops-per-second-real-time: 932687.530962
      wall-clock-time: 30.000742
      user-time: 7.858516
      system-time: 151.455654
      cpu-usage-per-instance: 66.379262
      max-rss: 2152

...
