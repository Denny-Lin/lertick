---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:24:01
      epoch-secs: 1795317841
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361645
      totalram: 4080812032
      freeram: 2260717568
      sharedram: 3543040
      bufferram: 33050624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 540122
      bogo-ops-per-second-usr-sys-time: 4580.799808
      bogo-ops-per-second-real-time: 36006.102307
      wall-clock-time: 15.000846
      user-time: 117.907978
      system-time: 0.001999
      cpu-usage-per-instance: 98.252772
      max-rss: 2560
      add-matrix-ops-per-sec: 315317.119227
      copy-matrix-ops-per-sec: 432062.328806
      div-matrix-ops-per-sec: 478897.958482
      frobenius-matrix-ops-per-sec: 81570.149015
      hadamard-matrix-ops-per-sec: 354444.926354
      identity-matrix-ops-per-sec: 409147.020973
      mean-matrix-ops-per-sec: 421614.533806
      mult-matrix-ops-per-sec: 537660.111014
      negate-matrix-ops-per-sec: 540837.747775
      prod-matrix-ops-per-sec: 631.062825
      sub-matrix-ops-per-sec: 401642.754600
      square-matrix-ops-per-sec: 674.624315
      trans-matrix-ops-per-sec: 145430.659654
      zero-matrix-ops-per-sec: 860341.587161

...
