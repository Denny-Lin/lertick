---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:24:16
      epoch-secs: 1795317856
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361660
      totalram: 4080812032
      freeram: 2253836288
      sharedram: 3543040
      bufferram: 33050624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 398154
      bogo-ops-per-second-usr-sys-time: 3333.585795
      bogo-ops-per-second-real-time: 26543.229209
      wall-clock-time: 15.000210
      user-time: 42.902722
      system-time: 76.534432
      cpu-usage-per-instance: 99.529571
      max-rss: 2280

...
