---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:23:31
      epoch-secs: 1795317811
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361615
      totalram: 4080812032
      freeram: 2255540224
      sharedram: 3543040
      bufferram: 33042432
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 166972
      bogo-ops-per-second-usr-sys-time: 1387.198448
      bogo-ops-per-second-real-time: 5565.502350
      wall-clock-time: 30.001245
      user-time: 4.472072
      system-time: 115.894268
      cpu-usage-per-instance: 50.150560
      max-rss: 2152

...
