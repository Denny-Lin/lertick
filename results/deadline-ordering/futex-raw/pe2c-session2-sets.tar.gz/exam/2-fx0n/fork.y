---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:12:08
      epoch-secs: 1795317128
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360933
      totalram: 4080812032
      freeram: 2254983168
      sharedram: 3543040
      bufferram: 32788480
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 398053
      bogo-ops-per-second-usr-sys-time: 3329.943517
      bogo-ops-per-second-real-time: 26536.509150
      wall-clock-time: 15.000202
      user-time: 43.044954
      system-time: 76.492509
      cpu-usage-per-instance: 99.613210
      max-rss: 2280

...
