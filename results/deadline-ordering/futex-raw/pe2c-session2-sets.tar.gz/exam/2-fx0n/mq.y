---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:11:38
      epoch-secs: 1795317098
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360902
      totalram: 4080812032
      freeram: 2265354240
      sharedram: 3543040
      bufferram: 32780288
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 43265790
      bogo-ops-per-second-usr-sys-time: 360749.951310
      bogo-ops-per-second-real-time: 2884265.372545
      wall-clock-time: 15.000627
      user-time: 17.301625
      system-time: 102.631281
      cpu-usage-per-instance: 99.939909
      max-rss: 2568

...
