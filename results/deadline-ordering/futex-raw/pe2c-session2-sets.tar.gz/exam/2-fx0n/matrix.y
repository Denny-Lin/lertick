---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:11:53
      epoch-secs: 1795317113
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360918
      totalram: 4080812032
      freeram: 2272559104
      sharedram: 3543040
      bufferram: 32788480
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 533700
      bogo-ops-per-second-usr-sys-time: 4482.687942
      bogo-ops-per-second-real-time: 35577.443993
      wall-clock-time: 15.001078
      user-time: 119.052032
      system-time: 0.005999
      cpu-usage-per-instance: 99.207898
      max-rss: 2564
      add-matrix-ops-per-sec: 328013.178828
      copy-matrix-ops-per-sec: 450803.972732
      div-matrix-ops-per-sec: 491537.151312
      frobenius-matrix-ops-per-sec: 78874.096875
      hadamard-matrix-ops-per-sec: 347736.345493
      identity-matrix-ops-per-sec: 398090.011468
      mean-matrix-ops-per-sec: 396281.759839
      mult-matrix-ops-per-sec: 518728.920287
      negate-matrix-ops-per-sec: 549866.005800
      prod-matrix-ops-per-sec: 623.891841
      sub-matrix-ops-per-sec: 384462.662558
      square-matrix-ops-per-sec: 666.249365
      trans-matrix-ops-per-sec: 145586.935545
      zero-matrix-ops-per-sec: 899333.398422

...
