---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:11:23
      epoch-secs: 1795317083
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360887
      totalram: 4080812032
      freeram: 2252349440
      sharedram: 3543040
      bufferram: 32780288
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 136938
      bogo-ops-per-second-usr-sys-time: 1137.953167
      bogo-ops-per-second-real-time: 4564.447713
      wall-clock-time: 30.001001
      user-time: 4.084578
      system-time: 116.252536
      cpu-usage-per-instance: 50.138791
      max-rss: 2176

...
