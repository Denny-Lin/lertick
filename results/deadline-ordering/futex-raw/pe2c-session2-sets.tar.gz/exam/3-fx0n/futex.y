---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:18:58
      epoch-secs: 1795317538
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361342
      totalram: 4080812032
      freeram: 2249592832
      sharedram: 3543040
      bufferram: 32931840
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 110814
      bogo-ops-per-second-usr-sys-time: 921.980701
      bogo-ops-per-second-real-time: 3693.656537
      wall-clock-time: 30.001165
      user-time: 3.740790
      system-time: 116.450446
      cpu-usage-per-instance: 50.077737
      max-rss: 2176

...
