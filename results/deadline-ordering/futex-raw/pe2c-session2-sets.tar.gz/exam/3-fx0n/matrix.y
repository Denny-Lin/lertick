---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:19:28
      epoch-secs: 1795317568
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361372
      totalram: 4080812032
      freeram: 2265554944
      sharedram: 3543040
      bufferram: 32976896
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 540952
      bogo-ops-per-second-usr-sys-time: 4555.887734
      bogo-ops-per-second-real-time: 36061.382297
      wall-clock-time: 15.000867
      user-time: 118.725905
      system-time: 0.010998
      cpu-usage-per-instance: 98.941700
      max-rss: 2560
      add-matrix-ops-per-sec: 322361.629184
      copy-matrix-ops-per-sec: 462241.492932
      div-matrix-ops-per-sec: 474285.634472
      frobenius-matrix-ops-per-sec: 81067.299787
      hadamard-matrix-ops-per-sec: 367119.546377
      identity-matrix-ops-per-sec: 399301.577511
      mean-matrix-ops-per-sec: 423011.777249
      mult-matrix-ops-per-sec: 515951.751777
      negate-matrix-ops-per-sec: 509481.605839
      prod-matrix-ops-per-sec: 631.529399
      sub-matrix-ops-per-sec: 403707.376490
      square-matrix-ops-per-sec: 676.226868
      trans-matrix-ops-per-sec: 145874.886515
      zero-matrix-ops-per-sec: 913010.355900

...
