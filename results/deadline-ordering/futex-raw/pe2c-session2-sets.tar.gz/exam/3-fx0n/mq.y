---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:19:13
      epoch-secs: 1795317553
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361357
      totalram: 4080812032
      freeram: 2254843904
      sharedram: 3543040
      bufferram: 32935936
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 43261754
      bogo-ops-per-second-usr-sys-time: 360708.323048
      bogo-ops-per-second-real-time: 2884009.398201
      wall-clock-time: 15.000559
      user-time: 17.239336
      system-time: 102.696222
      cpu-usage-per-instance: 99.942572
      max-rss: 2564

...
