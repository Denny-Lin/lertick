---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:19:43
      epoch-secs: 1795317583
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361387
      totalram: 4080812032
      freeram: 2245685248
      sharedram: 3543040
      bufferram: 32976896
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 400702
      bogo-ops-per-second-usr-sys-time: 3352.396749
      bogo-ops-per-second-real-time: 26713.096952
      wall-clock-time: 15.000208
      user-time: 42.845726
      system-time: 76.681296
      cpu-usage-per-instance: 99.604473
      max-rss: 2280

...
