---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:20:29
      epoch-secs: 1795317629
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361433
      totalram: 4080812032
      freeram: 2259120128
      sharedram: 3543040
      bufferram: 33001472
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 53865506
      bogo-ops-per-second-usr-sys-time: 346452.485297
      bogo-ops-per-second-real-time: 1795483.692508
      wall-clock-time: 30.000554
      user-time: 8.907003
      system-time: 146.570323
      cpu-usage-per-instance: 64.781022
      max-rss: 2180

...
