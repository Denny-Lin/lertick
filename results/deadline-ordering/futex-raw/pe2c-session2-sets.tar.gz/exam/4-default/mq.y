---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:20:44
      epoch-secs: 1795317644
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361448
      totalram: 4080812032
      freeram: 2251792384
      sharedram: 3543040
      bufferram: 33001472
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 43198556
      bogo-ops-per-second-usr-sys-time: 371205.375508
      bogo-ops-per-second-real-time: 2879808.404669
      wall-clock-time: 15.000497
      user-time: 18.510589
      system-time: 97.863146
      cpu-usage-per-instance: 96.974902
      max-rss: 2448

...
