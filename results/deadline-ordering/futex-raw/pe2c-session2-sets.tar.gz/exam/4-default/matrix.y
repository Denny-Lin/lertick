---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:20:59
      epoch-secs: 1795317659
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361463
      totalram: 4080812032
      freeram: 2264330240
      sharedram: 3543040
      bufferram: 33001472
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 543074
      bogo-ops-per-second-usr-sys-time: 4528.776054
      bogo-ops-per-second-real-time: 36201.986705
      wall-clock-time: 15.001221
      user-time: 119.912287
      system-time: 0.003998
      cpu-usage-per-instance: 99.922104
      max-rss: 2664
      add-matrix-ops-per-sec: 334190.727426
      copy-matrix-ops-per-sec: 449615.377804
      div-matrix-ops-per-sec: 486853.949586
      frobenius-matrix-ops-per-sec: 82233.103709
      hadamard-matrix-ops-per-sec: 362748.259295
      identity-matrix-ops-per-sec: 405695.575989
      mean-matrix-ops-per-sec: 421479.196189
      mult-matrix-ops-per-sec: 520124.212539
      negate-matrix-ops-per-sec: 539045.158216
      prod-matrix-ops-per-sec: 633.802155
      sub-matrix-ops-per-sec: 401248.312623
      square-matrix-ops-per-sec: 678.932755
      trans-matrix-ops-per-sec: 146919.125380
      zero-matrix-ops-per-sec: 881836.809815

...
