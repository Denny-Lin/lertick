---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:21:14
      epoch-secs: 1795317674
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361479
      totalram: 4080812032
      freeram: 2141208576
      sharedram: 3543040
      bufferram: 33001472
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 264195
      bogo-ops-per-second-usr-sys-time: 2713.473693
      bogo-ops-per-second-real-time: 17612.753472
      wall-clock-time: 15.000210
      user-time: 34.860361
      system-time: 62.503767
      cpu-usage-per-instance: 81.135638
      max-rss: 2308

...
