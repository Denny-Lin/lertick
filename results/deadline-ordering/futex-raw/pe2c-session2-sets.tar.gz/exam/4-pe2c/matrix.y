---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:22:30
      epoch-secs: 1795317750
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361554
      totalram: 4080812032
      freeram: 2246971392
      sharedram: 3543040
      bufferram: 33017856
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 538746
      bogo-ops-per-second-usr-sys-time: 4555.506483
      bogo-ops-per-second-real-time: 35914.741326
      wall-clock-time: 15.000693
      user-time: 118.255591
      system-time: 0.007000
      cpu-usage-per-instance: 98.547608
      max-rss: 2664
      add-matrix-ops-per-sec: 336208.652394
      copy-matrix-ops-per-sec: 456760.718094
      div-matrix-ops-per-sec: 481953.803295
      frobenius-matrix-ops-per-sec: 79334.333512
      hadamard-matrix-ops-per-sec: 382065.059565
      identity-matrix-ops-per-sec: 393752.619018
      mean-matrix-ops-per-sec: 416578.399487
      mult-matrix-ops-per-sec: 530642.094914
      negate-matrix-ops-per-sec: 546253.483503
      prod-matrix-ops-per-sec: 629.262105
      sub-matrix-ops-per-sec: 407516.563344
      square-matrix-ops-per-sec: 672.958847
      trans-matrix-ops-per-sec: 147363.117448
      zero-matrix-ops-per-sec: 919929.707326

...
