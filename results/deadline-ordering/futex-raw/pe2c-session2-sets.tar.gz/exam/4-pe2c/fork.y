---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:22:45
      epoch-secs: 1795317765
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361569
      totalram: 4080812032
      freeram: 2228989952
      sharedram: 3543040
      bufferram: 33026048
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 367542
      bogo-ops-per-second-usr-sys-time: 3175.108995
      bogo-ops-per-second-real-time: 24502.504743
      wall-clock-time: 15.000181
      user-time: 40.214563
      system-time: 75.542723
      cpu-usage-per-instance: 96.463243
      max-rss: 2308

...
