---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:22:00
      epoch-secs: 1795317720
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361524
      totalram: 4080812032
      freeram: 2248368128
      sharedram: 3543040
      bufferram: 33013760
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 26505892
      bogo-ops-per-second-usr-sys-time: 167351.346669
      bogo-ops-per-second-real-time: 883510.492639
      wall-clock-time: 30.000653
      user-time: 7.510613
      system-time: 150.874082
      cpu-usage-per-instance: 65.992186
      max-rss: 2152

...
