---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:22:15
      epoch-secs: 1795317735
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361539
      totalram: 4080812032
      freeram: 2248200192
      sharedram: 3543040
      bufferram: 33017856
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 22924207
      bogo-ops-per-second-usr-sys-time: 191188.297347
      bogo-ops-per-second-real-time: 1528236.992435
      wall-clock-time: 15.000427
      user-time: 8.500614
      system-time: 111.403205
      cpu-usage-per-instance: 99.917007
      max-rss: 2536

...
