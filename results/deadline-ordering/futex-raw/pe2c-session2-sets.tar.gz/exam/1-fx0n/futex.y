---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:09:52
      epoch-secs: 1795316992
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360796
      totalram: 4080812032
      freeram: 2255687680
      sharedram: 3543040
      bufferram: 32702464
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 99642
      bogo-ops-per-second-usr-sys-time: 828.421325
      bogo-ops-per-second-real-time: 3321.237395
      wall-clock-time: 30.001469
      user-time: 4.132842
      system-time: 116.146534
      cpu-usage-per-instance: 50.113953
      max-rss: 2152

...
