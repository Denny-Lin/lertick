---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:10:22
      epoch-secs: 1795317022
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360826
      totalram: 4080812032
      freeram: 2284421120
      sharedram: 3543040
      bufferram: 32714752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 543136
      bogo-ops-per-second-usr-sys-time: 4540.306050
      bogo-ops-per-second-real-time: 36206.866558
      wall-clock-time: 15.000911
      user-time: 119.620416
      system-time: 0.005000
      cpu-usage-per-instance: 99.681790
      max-rss: 2560
      add-matrix-ops-per-sec: 333627.587317
      copy-matrix-ops-per-sec: 447240.615619
      div-matrix-ops-per-sec: 503743.417892
      frobenius-matrix-ops-per-sec: 80780.823955
      hadamard-matrix-ops-per-sec: 366103.718344
      identity-matrix-ops-per-sec: 409038.068968
      mean-matrix-ops-per-sec: 415485.572394
      mult-matrix-ops-per-sec: 540760.638660
      negate-matrix-ops-per-sec: 535758.162015
      prod-matrix-ops-per-sec: 634.130892
      sub-matrix-ops-per-sec: 398723.353181
      square-matrix-ops-per-sec: 678.907366
      trans-matrix-ops-per-sec: 145039.648368
      zero-matrix-ops-per-sec: 856403.300914

...
