---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:10:37
      epoch-secs: 1795317037
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360841
      totalram: 4080812032
      freeram: 2265047040
      sharedram: 3543040
      bufferram: 32718848
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 393823
      bogo-ops-per-second-usr-sys-time: 3296.093005
      bogo-ops-per-second-real-time: 26254.424378
      wall-clock-time: 15.000253
      user-time: 42.669639
      system-time: 76.812123
      cpu-usage-per-instance: 99.566458
      max-rss: 2284

...
