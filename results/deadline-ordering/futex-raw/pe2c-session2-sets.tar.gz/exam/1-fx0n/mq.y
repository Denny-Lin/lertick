---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:10:07
      epoch-secs: 1795317007
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360811
      totalram: 4080812032
      freeram: 2260480000
      sharedram: 3543040
      bufferram: 32714752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 43306530
      bogo-ops-per-second-usr-sys-time: 361206.490648
      bogo-ops-per-second-real-time: 2886957.289766
      wall-clock-time: 15.000752
      user-time: 17.251016
      system-time: 102.643092
      cpu-usage-per-instance: 99.906749
      max-rss: 2576

...
