---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:06:49
      epoch-secs: 1795316809
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360613
      totalram: 4080812032
      freeram: 2488958976
      sharedram: 3543040
      bufferram: 28069888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 56491112
      bogo-ops-per-second-usr-sys-time: 350326.316121
      bogo-ops-per-second-real-time: 1883007.909620
      wall-clock-time: 30.000465
      user-time: 8.059798
      system-time: 153.193038
      cpu-usage-per-instance: 67.187641
      max-rss: 2180

...
