---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:07:34
      epoch-secs: 1795316854
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360659
      totalram: 4080812032
      freeram: 2428182528
      sharedram: 3543040
      bufferram: 28078080
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 277608
      bogo-ops-per-second-usr-sys-time: 2789.702648
      bogo-ops-per-second-real-time: 18506.964231
      wall-clock-time: 15.000191
      user-time: 35.866463
      system-time: 63.645218
      cpu-usage-per-instance: 82.925344
      max-rss: 2304

...
