---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:07:19
      epoch-secs: 1795316839
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360643
      totalram: 4080812032
      freeram: 2491928576
      sharedram: 3543040
      bufferram: 28078080
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 543596
      bogo-ops-per-second-usr-sys-time: 4532.014193
      bogo-ops-per-second-real-time: 36227.024564
      wall-clock-time: 15.005262
      user-time: 119.941785
      system-time: 0.004000
      cpu-usage-per-instance: 99.919768
      max-rss: 2484
      add-matrix-ops-per-sec: 315911.775720
      copy-matrix-ops-per-sec: 457711.107166
      div-matrix-ops-per-sec: 482712.582472
      frobenius-matrix-ops-per-sec: 81098.960274
      hadamard-matrix-ops-per-sec: 367817.046545
      identity-matrix-ops-per-sec: 397273.940542
      mean-matrix-ops-per-sec: 406158.537084
      mult-matrix-ops-per-sec: 518960.981263
      negate-matrix-ops-per-sec: 533917.907083
      prod-matrix-ops-per-sec: 634.567673
      sub-matrix-ops-per-sec: 407376.621952
      square-matrix-ops-per-sec: 679.674482
      trans-matrix-ops-per-sec: 146369.066691
      zero-matrix-ops-per-sec: 890403.171295

...
