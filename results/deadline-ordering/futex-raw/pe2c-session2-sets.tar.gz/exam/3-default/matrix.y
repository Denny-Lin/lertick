---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:17:58
      epoch-secs: 1795317478
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361282
      totalram: 4080812032
      freeram: 2255904768
      sharedram: 3543040
      bufferram: 32915456
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 541328
      bogo-ops-per-second-usr-sys-time: 4511.009414
      bogo-ops-per-second-real-time: 36086.453178
      wall-clock-time: 15.000865
      user-time: 119.999523
      system-time: 0.002000
      cpu-usage-per-instance: 99.995505
      max-rss: 2664
      add-matrix-ops-per-sec: 327874.960689
      copy-matrix-ops-per-sec: 447748.932136
      div-matrix-ops-per-sec: 501832.310391
      frobenius-matrix-ops-per-sec: 81849.515740
      hadamard-matrix-ops-per-sec: 360621.299484
      identity-matrix-ops-per-sec: 402295.975917
      mean-matrix-ops-per-sec: 408534.132934
      mult-matrix-ops-per-sec: 527884.272298
      negate-matrix-ops-per-sec: 534899.363528
      prod-matrix-ops-per-sec: 632.671638
      sub-matrix-ops-per-sec: 402139.155609
      square-matrix-ops-per-sec: 675.890836
      trans-matrix-ops-per-sec: 142750.293365
      zero-matrix-ops-per-sec: 852138.735182

...
