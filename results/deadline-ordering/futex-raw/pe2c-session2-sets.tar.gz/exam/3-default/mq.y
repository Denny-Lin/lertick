---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:17:43
      epoch-secs: 1795317463
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361267
      totalram: 4080812032
      freeram: 2245849088
      sharedram: 3543040
      bufferram: 32915456
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 40075687
      bogo-ops-per-second-usr-sys-time: 365113.098118
      bogo-ops-per-second-real-time: 2671620.988009
      wall-clock-time: 15.000514
      user-time: 17.495341
      system-time: 92.267051
      cpu-usage-per-instance: 91.465528
      max-rss: 2536

...
