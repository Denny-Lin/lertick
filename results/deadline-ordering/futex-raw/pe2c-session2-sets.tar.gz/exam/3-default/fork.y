---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:18:13
      epoch-secs: 1795317493
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361297
      totalram: 4080812032
      freeram: 2167668736
      sharedram: 3543040
      bufferram: 32919552
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 261314
      bogo-ops-per-second-usr-sys-time: 2706.146353
      bogo-ops-per-second-real-time: 17420.524330
      wall-clock-time: 15.000352
      user-time: 34.977529
      system-time: 61.585615
      cpu-usage-per-instance: 80.467397
      max-rss: 2308

...
