---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:12:55
      epoch-secs: 1795317175
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 360979
      totalram: 4080812032
      freeram: 2250301440
      sharedram: 3543040
      bufferram: 32808960
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 24247268
      bogo-ops-per-second-usr-sys-time: 154437.425048
      bogo-ops-per-second-real-time: 808214.982877
      wall-clock-time: 30.001013
      user-time: 7.177700
      system-time: 149.826135
      cpu-usage-per-instance: 65.416056
      max-rss: 2152

...
