---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:13:40
      epoch-secs: 1795317220
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361024
      totalram: 4080812032
      freeram: 2237689856
      sharedram: 3543040
      bufferram: 32813056
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 366656
      bogo-ops-per-second-usr-sys-time: 3167.765895
      bogo-ops-per-second-real-time: 24443.379151
      wall-clock-time: 15.000217
      user-time: 40.271284
      system-time: 75.474643
      cpu-usage-per-instance: 96.453542
      max-rss: 2308

...
