---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 03:13:25
      epoch-secs: 1795317205
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 361009
      totalram: 4080812032
      freeram: 2262360064
      sharedram: 3543040
      bufferram: 32813056
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 529227
      bogo-ops-per-second-usr-sys-time: 4447.779306
      bogo-ops-per-second-real-time: 35280.257407
      wall-clock-time: 15.000656
      user-time: 118.966779
      system-time: 0.020015
      cpu-usage-per-instance: 99.151326
      max-rss: 2564
      add-matrix-ops-per-sec: 321749.804399
      copy-matrix-ops-per-sec: 431312.549847
      div-matrix-ops-per-sec: 467908.314119
      frobenius-matrix-ops-per-sec: 78687.205149
      hadamard-matrix-ops-per-sec: 364000.854576
      identity-matrix-ops-per-sec: 386539.321348
      mean-matrix-ops-per-sec: 406077.704783
      mult-matrix-ops-per-sec: 527583.035760
      negate-matrix-ops-per-sec: 532891.573289
      prod-matrix-ops-per-sec: 617.731084
      sub-matrix-ops-per-sec: 407542.659574
      square-matrix-ops-per-sec: 661.682674
      trans-matrix-ops-per-sec: 141321.990726
      zero-matrix-ops-per-sec: 889662.149957

...
