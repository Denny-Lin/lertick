---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:31:23
      epoch-secs: 1795354283
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398087
      totalram: 4080812032
      freeram: 2547044352
      sharedram: 3551232
      bufferram: 32763904
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 60639032
      bogo-ops-per-second-usr-sys-time: 375232.091158
      bogo-ops-per-second-real-time: 2021253.340065
      wall-clock-time: 30.000708
      user-time: 8.870799
      system-time: 152.733268
      cpu-usage-per-instance: 67.333438
      max-rss: 2176

...
