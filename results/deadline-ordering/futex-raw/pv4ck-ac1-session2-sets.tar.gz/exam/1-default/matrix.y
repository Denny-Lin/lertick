---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:31:53
      epoch-secs: 1795354313
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398117
      totalram: 4080812032
      freeram: 2549579776
      sharedram: 3551232
      bufferram: 32772096
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 538748
      bogo-ops-per-second-usr-sys-time: 4493.197282
      bogo-ops-per-second-real-time: 35914.099632
      wall-clock-time: 15.001016
      user-time: 119.900037
      system-time: 0.003000
      cpu-usage-per-instance: 99.912427
      max-rss: 2596
      add-matrix-ops-per-sec: 315017.171978
      copy-matrix-ops-per-sec: 457881.339666
      div-matrix-ops-per-sec: 482084.725791
      frobenius-matrix-ops-per-sec: 78974.148849
      hadamard-matrix-ops-per-sec: 380066.022702
      identity-matrix-ops-per-sec: 391002.738383
      mean-matrix-ops-per-sec: 423245.424251
      mult-matrix-ops-per-sec: 519701.809587
      negate-matrix-ops-per-sec: 536329.725056
      prod-matrix-ops-per-sec: 628.632517
      sub-matrix-ops-per-sec: 383475.596707
      square-matrix-ops-per-sec: 674.080379
      trans-matrix-ops-per-sec: 144927.862601
      zero-matrix-ops-per-sec: 859071.769100

...
