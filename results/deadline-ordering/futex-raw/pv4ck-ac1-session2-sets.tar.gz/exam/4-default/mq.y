---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:54:27
      epoch-secs: 1795355667
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399472
      totalram: 4080812032
      freeram: 2317897728
      sharedram: 3551232
      bufferram: 34611200
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 42652569
      bogo-ops-per-second-usr-sys-time: 366449.472445
      bogo-ops-per-second-real-time: 2843392.828323
      wall-clock-time: 15.000590
      user-time: 18.488982
      system-time: 97.905152
      cpu-usage-per-instance: 96.991299
      max-rss: 2536

...
