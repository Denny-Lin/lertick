---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:54:12
      epoch-secs: 1795355652
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399456
      totalram: 4080812032
      freeram: 2328276992
      sharedram: 3551232
      bufferram: 34611200
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 60689412
      bogo-ops-per-second-usr-sys-time: 375388.170066
      bogo-ops-per-second-real-time: 2022945.466849
      wall-clock-time: 30.000518
      user-time: 9.174497
      system-time: 152.496586
      cpu-usage-per-instance: 67.361788
      max-rss: 2176

...
