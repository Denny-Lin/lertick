---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:10:45
      epoch-secs: 1795356645
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400449
      totalram: 4080812032
      freeram: 2012958720
      sharedram: 3551232
      bufferram: 37187584
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 226872
      bogo-ops-per-second-usr-sys-time: 2415.886788
      bogo-ops-per-second-real-time: 15124.492021
      wall-clock-time: 15.000305
      user-time: 31.462179
      system-time: 62.446195
      cpu-usage-per-instance: 78.255385
      max-rss: 2320

...
