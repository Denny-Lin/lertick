---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:43:48
      epoch-secs: 1795355028
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398832
      totalram: 4080812032
      freeram: 2339545088
      sharedram: 3551232
      bufferram: 34168832
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 42590387
      bogo-ops-per-second-usr-sys-time: 370328.169773
      bogo-ops-per-second-real-time: 2839257.091529
      wall-clock-time: 15.000539
      user-time: 18.307267
      system-time: 96.699882
      cpu-usage-per-instance: 95.835847
      max-rss: 2536

...
