---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:43:33
      epoch-secs: 1795355013
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398817
      totalram: 4080812032
      freeram: 2328236032
      sharedram: 3551232
      bufferram: 34168832
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 58079222
      bogo-ops-per-second-usr-sys-time: 359546.086053
      bogo-ops-per-second-real-time: 1935937.247369
      wall-clock-time: 30.000571
      user-time: 8.460098
      system-time: 153.074749
      cpu-usage-per-instance: 67.304906
      max-rss: 2180

...
