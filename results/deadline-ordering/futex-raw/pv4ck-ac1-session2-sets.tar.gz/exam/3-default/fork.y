---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:44:18
      epoch-secs: 1795355058
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398862
      totalram: 4080812032
      freeram: 2027823104
      sharedram: 3551232
      bufferram: 34177024
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 263723
      bogo-ops-per-second-usr-sys-time: 2699.876697
      bogo-ops-per-second-real-time: 17581.134286
      wall-clock-time: 15.000340
      user-time: 34.971868
      system-time: 62.707778
      cpu-usage-per-instance: 81.397857
      max-rss: 2320

...
