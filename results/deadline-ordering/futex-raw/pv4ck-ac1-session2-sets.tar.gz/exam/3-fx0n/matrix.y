---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:47:05
      epoch-secs: 1795355225
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399029
      totalram: 4080812032
      freeram: 2326765568
      sharedram: 3551232
      bufferram: 34246656
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 540880
      bogo-ops-per-second-usr-sys-time: 4547.675994
      bogo-ops-per-second-real-time: 36056.364809
      wall-clock-time: 15.000958
      user-time: 118.928475
      system-time: 0.006999
      cpu-usage-per-instance: 99.106568
      max-rss: 2560
      add-matrix-ops-per-sec: 314979.887762
      copy-matrix-ops-per-sec: 469288.458855
      div-matrix-ops-per-sec: 467140.224319
      frobenius-matrix-ops-per-sec: 79627.137240
      hadamard-matrix-ops-per-sec: 377711.475608
      identity-matrix-ops-per-sec: 401298.592037
      mean-matrix-ops-per-sec: 432949.164557
      mult-matrix-ops-per-sec: 531590.624125
      negate-matrix-ops-per-sec: 546736.122486
      prod-matrix-ops-per-sec: 631.285608
      sub-matrix-ops-per-sec: 410117.930314
      square-matrix-ops-per-sec: 676.413545
      trans-matrix-ops-per-sec: 144070.584125
      zero-matrix-ops-per-sec: 852018.347053

...
