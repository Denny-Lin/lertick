---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:46:35
      epoch-secs: 1795355195
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398999
      totalram: 4080812032
      freeram: 2315194368
      sharedram: 3551232
      bufferram: 34238464
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 156656
      bogo-ops-per-second-usr-sys-time: 1301.431016
      bogo-ops-per-second-real-time: 5221.699719
      wall-clock-time: 30.000959
      user-time: 3.845256
      system-time: 116.526856
      cpu-usage-per-instance: 50.153443
      max-rss: 2188

...
