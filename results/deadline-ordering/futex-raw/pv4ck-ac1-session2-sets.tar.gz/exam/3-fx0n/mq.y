---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:46:50
      epoch-secs: 1795355210
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399014
      totalram: 4080812032
      freeram: 2320252928
      sharedram: 3551232
      bufferram: 34246656
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 40292823
      bogo-ops-per-second-usr-sys-time: 336323.183584
      bogo-ops-per-second-real-time: 2686053.159937
      wall-clock-time: 15.000754
      user-time: 16.294414
      system-time: 103.509468
      cpu-usage-per-instance: 99.831549
      max-rss: 2544

...
