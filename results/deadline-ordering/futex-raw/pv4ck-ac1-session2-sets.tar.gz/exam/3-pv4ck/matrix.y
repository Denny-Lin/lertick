---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:45:34
      epoch-secs: 1795355134
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398938
      totalram: 4080812032
      freeram: 2333601792
      sharedram: 3551232
      bufferram: 34217984
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 511506
      bogo-ops-per-second-usr-sys-time: 4337.429356
      bogo-ops-per-second-real-time: 34097.392238
      wall-clock-time: 15.001323
      user-time: 117.845673
      system-time: 0.082703
      cpu-usage-per-instance: 98.264979
      max-rss: 2596
      add-matrix-ops-per-sec: 319838.215554
      copy-matrix-ops-per-sec: 465432.529058
      div-matrix-ops-per-sec: 471273.872200
      frobenius-matrix-ops-per-sec: 77120.946916
      hadamard-matrix-ops-per-sec: 376057.222193
      identity-matrix-ops-per-sec: 384854.451190
      mean-matrix-ops-per-sec: 409652.042418
      mult-matrix-ops-per-sec: 503484.374899
      negate-matrix-ops-per-sec: 517231.139945
      prod-matrix-ops-per-sec: 595.099435
      sub-matrix-ops-per-sec: 406617.140811
      square-matrix-ops-per-sec: 641.437185
      trans-matrix-ops-per-sec: 136895.870403
      zero-matrix-ops-per-sec: 824529.859549

...
