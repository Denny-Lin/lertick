---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:45:04
      epoch-secs: 1795355104
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398908
      totalram: 4080812032
      freeram: 2322190336
      sharedram: 3551232
      bufferram: 34209792
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 33851668
      bogo-ops-per-second-usr-sys-time: 206966.107800
      bogo-ops-per-second-real-time: 1128121.866567
      wall-clock-time: 30.007102
      user-time: 9.784577
      system-time: 153.776831
      cpu-usage-per-instance: 68.134457
      max-rss: 2156

...
