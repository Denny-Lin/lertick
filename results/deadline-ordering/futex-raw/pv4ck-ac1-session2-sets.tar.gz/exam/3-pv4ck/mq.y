---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:45:19
      epoch-secs: 1795355119
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398923
      totalram: 4080812032
      freeram: 2334101504
      sharedram: 3551232
      bufferram: 34209792
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 41129207
      bogo-ops-per-second-usr-sys-time: 344805.541435
      bogo-ops-per-second-real-time: 2741803.597833
      wall-clock-time: 15.000785
      user-time: 18.046629
      system-time: 101.235697
      cpu-usage-per-instance: 99.396735
      max-rss: 2544

...
