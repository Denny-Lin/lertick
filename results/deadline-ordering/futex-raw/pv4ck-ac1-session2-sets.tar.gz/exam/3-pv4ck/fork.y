---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:45:49
      epoch-secs: 1795355149
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398953
      totalram: 4080812032
      freeram: 2298003456
      sharedram: 3551232
      bufferram: 34217984
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 361874
      bogo-ops-per-second-usr-sys-time: 3097.350162
      bogo-ops-per-second-real-time: 24124.430202
      wall-clock-time: 15.000313
      user-time: 39.766461
      system-time: 77.066955
      cpu-usage-per-instance: 97.359150
      max-rss: 2308

...
