---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:42:02
      epoch-secs: 1795354922
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398726
      totalram: 4080812032
      freeram: 2321207296
      sharedram: 3551232
      bufferram: 34095104
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 37748776
      bogo-ops-per-second-usr-sys-time: 227889.773453
      bogo-ops-per-second-real-time: 1258252.464567
      wall-clock-time: 30.000955
      user-time: 9.786775
      system-time: 155.858113
      cpu-usage-per-instance: 69.016506
      max-rss: 2176

...
