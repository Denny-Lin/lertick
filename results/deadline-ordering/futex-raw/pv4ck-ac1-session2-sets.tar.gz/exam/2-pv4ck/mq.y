---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:42:17
      epoch-secs: 1795354937
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398741
      totalram: 4080812032
      freeram: 2319417344
      sharedram: 3551232
      bufferram: 34107392
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 47012109
      bogo-ops-per-second-usr-sys-time: 392143.130476
      bogo-ops-per-second-real-time: 3134038.088616
      wall-clock-time: 15.000491
      user-time: 18.510875
      system-time: 101.374201
      cpu-usage-per-instance: 99.900962
      max-rss: 2572

...
