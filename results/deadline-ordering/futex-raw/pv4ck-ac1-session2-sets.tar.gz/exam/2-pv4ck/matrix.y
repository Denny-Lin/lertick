---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:42:32
      epoch-secs: 1795354952
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398756
      totalram: 4080812032
      freeram: 2321223680
      sharedram: 3547136
      bufferram: 34107392
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 527702
      bogo-ops-per-second-usr-sys-time: 4464.747693
      bogo-ops-per-second-real-time: 35177.704383
      wall-clock-time: 15.001036
      user-time: 118.157961
      system-time: 0.035056
      cpu-usage-per-instance: 98.487380
      max-rss: 2664
      add-matrix-ops-per-sec: 321514.429157
      copy-matrix-ops-per-sec: 462452.699953
      div-matrix-ops-per-sec: 459334.824457
      frobenius-matrix-ops-per-sec: 79358.715862
      hadamard-matrix-ops-per-sec: 374275.572220
      identity-matrix-ops-per-sec: 384666.704165
      mean-matrix-ops-per-sec: 371224.256810
      mult-matrix-ops-per-sec: 529043.794132
      negate-matrix-ops-per-sec: 517415.650889
      prod-matrix-ops-per-sec: 614.353995
      sub-matrix-ops-per-sec: 403979.162193
      square-matrix-ops-per-sec: 661.722014
      trans-matrix-ops-per-sec: 144770.215183
      zero-matrix-ops-per-sec: 825368.380790

...
