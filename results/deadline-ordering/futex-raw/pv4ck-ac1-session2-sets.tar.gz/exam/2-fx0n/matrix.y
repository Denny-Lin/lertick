---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:39:29
      epoch-secs: 1795354769
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398573
      totalram: 4080812032
      freeram: 2334978048
      sharedram: 3551232
      bufferram: 34037760
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 540120
      bogo-ops-per-second-usr-sys-time: 4513.119682
      bogo-ops-per-second-real-time: 36005.822409
      wall-clock-time: 15.000907
      user-time: 119.672748
      system-time: 0.005000
      cpu-usage-per-instance: 99.725425
      max-rss: 2532
      add-matrix-ops-per-sec: 332303.707482
      copy-matrix-ops-per-sec: 453576.990739
      div-matrix-ops-per-sec: 491097.822527
      frobenius-matrix-ops-per-sec: 80121.901215
      hadamard-matrix-ops-per-sec: 378227.007301
      identity-matrix-ops-per-sec: 396542.065856
      mean-matrix-ops-per-sec: 413067.878094
      mult-matrix-ops-per-sec: 524209.263025
      negate-matrix-ops-per-sec: 544801.439713
      prod-matrix-ops-per-sec: 630.304721
      sub-matrix-ops-per-sec: 391351.463885
      square-matrix-ops-per-sec: 675.486171
      trans-matrix-ops-per-sec: 144240.946196
      zero-matrix-ops-per-sec: 905754.130833

...
