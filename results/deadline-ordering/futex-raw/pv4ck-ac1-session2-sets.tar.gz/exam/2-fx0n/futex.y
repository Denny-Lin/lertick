---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:38:59
      epoch-secs: 1795354739
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398543
      totalram: 4080812032
      freeram: 2327871488
      sharedram: 3551232
      bufferram: 34029568
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 101898
      bogo-ops-per-second-usr-sys-time: 847.135730
      bogo-ops-per-second-real-time: 3396.495021
      wall-clock-time: 30.000927
      user-time: 5.234152
      system-time: 115.051177
      cpu-usage-per-instance: 50.117338
      max-rss: 2152

...
