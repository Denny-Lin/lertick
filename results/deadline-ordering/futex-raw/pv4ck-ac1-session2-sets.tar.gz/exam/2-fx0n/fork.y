---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:39:44
      epoch-secs: 1795354784
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398588
      totalram: 4080812032
      freeram: 2320859136
      sharedram: 3551232
      bufferram: 34045952
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 394132
      bogo-ops-per-second-usr-sys-time: 3300.860146
      bogo-ops-per-second-real-time: 26275.014060
      wall-clock-time: 15.000258
      user-time: 42.331057
      system-time: 77.071760
      cpu-usage-per-instance: 99.500634
      max-rss: 2280

...
