---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:33:25
      epoch-secs: 1795354405
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398209
      totalram: 4080812032
      freeram: 2350264320
      sharedram: 3551232
      bufferram: 33878016
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 539820
      bogo-ops-per-second-usr-sys-time: 4504.703051
      bogo-ops-per-second-real-time: 35985.674699
      wall-clock-time: 15.000969
      user-time: 119.820755
      system-time: 0.014003
      cpu-usage-per-instance: 99.855846
      max-rss: 2664
      add-matrix-ops-per-sec: 331662.296783
      copy-matrix-ops-per-sec: 453030.008944
      div-matrix-ops-per-sec: 478262.404889
      frobenius-matrix-ops-per-sec: 80571.595100
      hadamard-matrix-ops-per-sec: 377879.610154
      identity-matrix-ops-per-sec: 398511.482200
      mean-matrix-ops-per-sec: 427122.732427
      mult-matrix-ops-per-sec: 529194.216530
      negate-matrix-ops-per-sec: 576173.118148
      prod-matrix-ops-per-sec: 630.503449
      sub-matrix-ops-per-sec: 407377.714640
      square-matrix-ops-per-sec: 674.462323
      trans-matrix-ops-per-sec: 142804.901057
      zero-matrix-ops-per-sec: 874629.602428

...
