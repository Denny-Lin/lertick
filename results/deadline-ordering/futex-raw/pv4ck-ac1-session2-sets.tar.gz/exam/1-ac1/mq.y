---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:33:10
      epoch-secs: 1795354390
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398194
      totalram: 4080812032
      freeram: 2346647552
      sharedram: 3551232
      bufferram: 33878016
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 52445893
      bogo-ops-per-second-usr-sys-time: 437503.138153
      bogo-ops-per-second-real-time: 3496245.929117
      wall-clock-time: 15.000630
      user-time: 21.162809
      system-time: 98.712658
      cpu-usage-per-instance: 99.892024
      max-rss: 2576

...
