---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:33:40
      epoch-secs: 1795354420
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398224
      totalram: 4080812032
      freeram: 2306260992
      sharedram: 3551232
      bufferram: 33886208
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 366820
      bogo-ops-per-second-usr-sys-time: 3130.363084
      bogo-ops-per-second-real-time: 24454.191349
      wall-clock-time: 15.000292
      user-time: 40.507115
      system-time: 76.674180
      cpu-usage-per-instance: 97.649181
      max-rss: 2308

...
