---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:32:55
      epoch-secs: 1795354375
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398179
      totalram: 4080812032
      freeram: 2337497088
      sharedram: 3551232
      bufferram: 33869824
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 47774486
      bogo-ops-per-second-usr-sys-time: 282044.930456
      bogo-ops-per-second-real-time: 1592416.740666
      wall-clock-time: 30.001246
      user-time: 10.381010
      system-time: 159.005073
      cpu-usage-per-instance: 70.574604
      max-rss: 2156

...
