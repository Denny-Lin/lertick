---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:34:56
      epoch-secs: 1795354496
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398300
      totalram: 4080812032
      freeram: 2350469120
      sharedram: 3551232
      bufferram: 33910784
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 536414
      bogo-ops-per-second-usr-sys-time: 4506.170310
      bogo-ops-per-second-real-time: 35757.985971
      wall-clock-time: 15.001236
      user-time: 119.025874
      system-time: 0.014012
      cpu-usage-per-instance: 99.191729
      max-rss: 2664
      add-matrix-ops-per-sec: 319901.932168
      copy-matrix-ops-per-sec: 454313.045886
      div-matrix-ops-per-sec: 488652.574153
      frobenius-matrix-ops-per-sec: 78714.839815
      hadamard-matrix-ops-per-sec: 364414.352927
      identity-matrix-ops-per-sec: 395262.135145
      mean-matrix-ops-per-sec: 427759.306079
      mult-matrix-ops-per-sec: 538273.139113
      negate-matrix-ops-per-sec: 541790.130076
      prod-matrix-ops-per-sec: 625.095951
      sub-matrix-ops-per-sec: 397752.411809
      square-matrix-ops-per-sec: 671.952464
      trans-matrix-ops-per-sec: 141787.405828
      zero-matrix-ops-per-sec: 859052.751325

...
