---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:35:11
      epoch-secs: 1795354511
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398315
      totalram: 4080812032
      freeram: 2299367424
      sharedram: 3551232
      bufferram: 33910784
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 368353
      bogo-ops-per-second-usr-sys-time: 3141.783210
      bogo-ops-per-second-real-time: 24556.453714
      wall-clock-time: 15.000252
      user-time: 40.549153
      system-time: 76.694137
      cpu-usage-per-instance: 97.701099
      max-rss: 2308

...
