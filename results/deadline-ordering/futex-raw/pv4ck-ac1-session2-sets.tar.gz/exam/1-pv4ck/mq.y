---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:34:41
      epoch-secs: 1795354481
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398285
      totalram: 4080812032
      freeram: 2334965760
      sharedram: 3551232
      bufferram: 33910784
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 46650640
      bogo-ops-per-second-usr-sys-time: 389582.494886
      bogo-ops-per-second-real-time: 3109923.692655
      wall-clock-time: 15.000574
      user-time: 18.593026
      system-time: 101.152190
      cpu-usage-per-instance: 99.783863
      max-rss: 2544

...
