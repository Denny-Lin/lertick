---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:34:26
      epoch-secs: 1795354466
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398270
      totalram: 4080812032
      freeram: 2333483008
      sharedram: 3551232
      bufferram: 33902592
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 38212844
      bogo-ops-per-second-usr-sys-time: 230679.794149
      bogo-ops-per-second-real-time: 1273721.670811
      wall-clock-time: 30.000937
      user-time: 9.374789
      system-time: 156.278402
      cpu-usage-per-instance: 69.020006
      max-rss: 2156

...
