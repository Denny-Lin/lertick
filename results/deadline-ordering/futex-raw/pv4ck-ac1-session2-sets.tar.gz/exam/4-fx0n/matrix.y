---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:50:08
      epoch-secs: 1795355408
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399212
      totalram: 4080812032
      freeram: 2325864448
      sharedram: 3551232
      bufferram: 34340864
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 536260
      bogo-ops-per-second-usr-sys-time: 4551.172888
      bogo-ops-per-second-real-time: 35748.529922
      wall-clock-time: 15.000897
      user-time: 117.821971
      system-time: 0.006996
      cpu-usage-per-instance: 98.184937
      max-rss: 2548
      add-matrix-ops-per-sec: 325088.551539
      copy-matrix-ops-per-sec: 454187.764540
      div-matrix-ops-per-sec: 473566.722318
      frobenius-matrix-ops-per-sec: 79332.396570
      hadamard-matrix-ops-per-sec: 372874.587778
      identity-matrix-ops-per-sec: 402935.954186
      mean-matrix-ops-per-sec: 413699.324520
      mult-matrix-ops-per-sec: 508260.610049
      negate-matrix-ops-per-sec: 544103.728309
      prod-matrix-ops-per-sec: 624.995147
      sub-matrix-ops-per-sec: 397081.950756
      square-matrix-ops-per-sec: 671.751908
      trans-matrix-ops-per-sec: 143832.738929
      zero-matrix-ops-per-sec: 823230.059653

...
