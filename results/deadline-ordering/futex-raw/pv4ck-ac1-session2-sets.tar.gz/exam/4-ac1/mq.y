---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:51:24
      epoch-secs: 1795355484
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399288
      totalram: 4080812032
      freeram: 2319572992
      sharedram: 3551232
      bufferram: 34508800
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 52277641
      bogo-ops-per-second-usr-sys-time: 436142.702688
      bogo-ops-per-second-real-time: 3485018.536246
      wall-clock-time: 15.000678
      user-time: 20.672426
      system-time: 99.191189
      cpu-usage-per-instance: 99.881831
      max-rss: 2548

...
