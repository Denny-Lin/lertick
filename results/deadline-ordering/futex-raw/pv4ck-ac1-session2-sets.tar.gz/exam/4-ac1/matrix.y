---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:51:39
      epoch-secs: 1795355499
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399303
      totalram: 4080812032
      freeram: 2333261824
      sharedram: 3551232
      bufferram: 34508800
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 538042
      bogo-ops-per-second-usr-sys-time: 4509.612591
      bogo-ops-per-second-real-time: 35867.745527
      wall-clock-time: 15.000720
      user-time: 119.295028
      system-time: 0.014999
      cpu-usage-per-instance: 99.420252
      max-rss: 2560
      add-matrix-ops-per-sec: 321315.193935
      copy-matrix-ops-per-sec: 477547.890173
      div-matrix-ops-per-sec: 478227.815605
      frobenius-matrix-ops-per-sec: 80713.193358
      hadamard-matrix-ops-per-sec: 381721.103313
      identity-matrix-ops-per-sec: 394395.880772
      mean-matrix-ops-per-sec: 412170.390501
      mult-matrix-ops-per-sec: 536237.367934
      negate-matrix-ops-per-sec: 543233.800168
      prod-matrix-ops-per-sec: 628.499816
      sub-matrix-ops-per-sec: 407396.941275
      square-matrix-ops-per-sec: 672.153914
      trans-matrix-ops-per-sec: 142990.641765
      zero-matrix-ops-per-sec: 865893.436685

...
