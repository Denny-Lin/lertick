---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:53:11
      epoch-secs: 1795355591
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399395
      totalram: 4080812032
      freeram: 2326683648
      sharedram: 3551232
      bufferram: 34578432
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 541116
      bogo-ops-per-second-usr-sys-time: 4543.325533
      bogo-ops-per-second-real-time: 36072.565684
      wall-clock-time: 15.000763
      user-time: 119.099307
      system-time: 0.001998
      cpu-usage-per-instance: 99.246041
      max-rss: 2664
      add-matrix-ops-per-sec: 328332.474443
      copy-matrix-ops-per-sec: 441640.938213
      div-matrix-ops-per-sec: 465853.972147
      frobenius-matrix-ops-per-sec: 79730.150276
      hadamard-matrix-ops-per-sec: 368783.297679
      identity-matrix-ops-per-sec: 392065.253168
      mean-matrix-ops-per-sec: 410507.403158
      mult-matrix-ops-per-sec: 531674.336580
      negate-matrix-ops-per-sec: 552090.342042
      prod-matrix-ops-per-sec: 631.634318
      sub-matrix-ops-per-sec: 406033.807001
      square-matrix-ops-per-sec: 676.651142
      trans-matrix-ops-per-sec: 145850.932410
      zero-matrix-ops-per-sec: 873852.764967

...
