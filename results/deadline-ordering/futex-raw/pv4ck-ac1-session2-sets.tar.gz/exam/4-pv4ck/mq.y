---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:52:56
      epoch-secs: 1795355576
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399380
      totalram: 4080812032
      freeram: 2323890176
      sharedram: 3551232
      bufferram: 34545664
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 47248569
      bogo-ops-per-second-usr-sys-time: 394351.133272
      bogo-ops-per-second-real-time: 3149769.213797
      wall-clock-time: 15.000645
      user-time: 18.647240
      system-time: 101.166208
      cpu-usage-per-instance: 99.840249
      max-rss: 2536

...
