---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:41:00
      epoch-secs: 1795354860
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398665
      totalram: 4080812032
      freeram: 2337509376
      sharedram: 3551232
      bufferram: 34074624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 535784
      bogo-ops-per-second-usr-sys-time: 4571.713322
      bogo-ops-per-second-real-time: 35716.591642
      wall-clock-time: 15.000983
      user-time: 117.189450
      system-time: 0.006000
      cpu-usage-per-instance: 97.656472
      max-rss: 2664
      add-matrix-ops-per-sec: 335858.750432
      copy-matrix-ops-per-sec: 455168.295279
      div-matrix-ops-per-sec: 481042.503211
      frobenius-matrix-ops-per-sec: 81051.997345
      hadamard-matrix-ops-per-sec: 377313.532386
      identity-matrix-ops-per-sec: 397042.882068
      mean-matrix-ops-per-sec: 389851.922966
      mult-matrix-ops-per-sec: 539435.871033
      negate-matrix-ops-per-sec: 540489.089766
      prod-matrix-ops-per-sec: 625.751834
      sub-matrix-ops-per-sec: 421561.823924
      square-matrix-ops-per-sec: 669.355077
      trans-matrix-ops-per-sec: 141446.569369
      zero-matrix-ops-per-sec: 886522.534663

...
