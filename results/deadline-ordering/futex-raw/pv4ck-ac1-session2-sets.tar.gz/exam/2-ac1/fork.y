---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:41:15
      epoch-secs: 1795354875
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398680
      totalram: 4080812032
      freeram: 2299645952
      sharedram: 3551232
      bufferram: 34074624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 363129
      bogo-ops-per-second-usr-sys-time: 3105.928951
      bogo-ops-per-second-real-time: 24208.107389
      wall-clock-time: 15.000305
      user-time: 39.893911
      system-time: 77.020869
      cpu-usage-per-instance: 97.427001
      max-rss: 2280

...
