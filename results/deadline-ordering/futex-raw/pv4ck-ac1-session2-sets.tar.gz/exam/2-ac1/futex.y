---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:40:30
      epoch-secs: 1795354830
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398635
      totalram: 4080812032
      freeram: 2324529152
      sharedram: 3551232
      bufferram: 34066432
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 47428646
      bogo-ops-per-second-usr-sys-time: 279651.812881
      bogo-ops-per-second-real-time: 1580922.145194
      wall-clock-time: 30.000621
      user-time: 9.888641
      system-time: 159.710281
      cpu-usage-per-instance: 70.664755
      max-rss: 2152

...
