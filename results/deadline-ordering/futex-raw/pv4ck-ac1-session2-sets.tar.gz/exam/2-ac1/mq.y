---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:40:45
      epoch-secs: 1795354845
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398650
      totalram: 4080812032
      freeram: 2329907200
      sharedram: 3551232
      bufferram: 34070528
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 52171278
      bogo-ops-per-second-usr-sys-time: 435397.168005
      bogo-ops-per-second-real-time: 3477942.465990
      wall-clock-time: 15.000616
      user-time: 20.714191
      system-time: 99.110378
      cpu-usage-per-instance: 99.849710
      max-rss: 2548

...
