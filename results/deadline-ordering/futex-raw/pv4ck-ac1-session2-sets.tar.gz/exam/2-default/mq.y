---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:37:43
      epoch-secs: 1795354663
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398468
      totalram: 4080812032
      freeram: 2331009024
      sharedram: 3551232
      bufferram: 33992704
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 42413437
      bogo-ops-per-second-usr-sys-time: 369069.795067
      bogo-ops-per-second-real-time: 2827449.158933
      wall-clock-time: 15.000601
      user-time: 18.442458
      system-time: 96.477369
      cpu-usage-per-instance: 95.762685
      max-rss: 2536

...
