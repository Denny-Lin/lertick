---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:37:58
      epoch-secs: 1795354678
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398483
      totalram: 4080812032
      freeram: 2341642240
      sharedram: 3551232
      bufferram: 34000896
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 539804
      bogo-ops-per-second-usr-sys-time: 4499.372051
      bogo-ops-per-second-real-time: 35985.132134
      wall-clock-time: 15.000751
      user-time: 119.971184
      system-time: 0.002002
      cpu-usage-per-instance: 99.972651
      max-rss: 2664
      add-matrix-ops-per-sec: 317245.312041
      copy-matrix-ops-per-sec: 457537.119321
      div-matrix-ops-per-sec: 467014.438664
      frobenius-matrix-ops-per-sec: 79371.596170
      hadamard-matrix-ops-per-sec: 376076.139777
      identity-matrix-ops-per-sec: 390595.497878
      mean-matrix-ops-per-sec: 414636.328743
      mult-matrix-ops-per-sec: 520919.822533
      negate-matrix-ops-per-sec: 537565.315907
      prod-matrix-ops-per-sec: 629.884703
      sub-matrix-ops-per-sec: 414717.035332
      square-matrix-ops-per-sec: 675.277111
      trans-matrix-ops-per-sec: 146883.705779
      zero-matrix-ops-per-sec: 873041.945815

...
