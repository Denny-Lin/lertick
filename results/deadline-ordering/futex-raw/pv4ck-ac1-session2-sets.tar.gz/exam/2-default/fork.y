---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:38:13
      epoch-secs: 1795354693
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398498
      totalram: 4080812032
      freeram: 2062987264
      sharedram: 3551232
      bufferram: 34004992
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 267042
      bogo-ops-per-second-usr-sys-time: 2714.205509
      bogo-ops-per-second-real-time: 17802.414677
      wall-clock-time: 15.000325
      user-time: 35.071807
      system-time: 63.314995
      cpu-usage-per-instance: 81.987227
      max-rss: 2308

...
