---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:48:51
      epoch-secs: 1795355331
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399136
      totalram: 4080812032
      freeram: 2292154368
      sharedram: 3551232
      bufferram: 34308096
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 364978
      bogo-ops-per-second-usr-sys-time: 3122.475775
      bogo-ops-per-second-real-time: 24331.546350
      wall-clock-time: 15.000197
      user-time: 40.222605
      system-time: 76.664771
      cpu-usage-per-instance: 97.404864
      max-rss: 2280

...
