---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:48:06
      epoch-secs: 1795355286
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399091
      totalram: 4080812032
      freeram: 2315763712
      sharedram: 3551232
      bufferram: 34287616
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 48346826
      bogo-ops-per-second-usr-sys-time: 285233.112345
      bogo-ops-per-second-real-time: 1611502.809000
      wall-clock-time: 30.001081
      user-time: 10.282592
      system-time: 159.216754
      cpu-usage-per-instance: 70.622183
      max-rss: 2176

...
