---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:48:36
      epoch-secs: 1795355316
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399121
      totalram: 4080812032
      freeram: 2319306752
      sharedram: 3551232
      bufferram: 34308096
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 537299
      bogo-ops-per-second-usr-sys-time: 4522.156973
      bogo-ops-per-second-real-time: 35818.040654
      wall-clock-time: 15.000793
      user-time: 118.797766
      system-time: 0.016995
      cpu-usage-per-instance: 99.007069
      max-rss: 2664
      add-matrix-ops-per-sec: 330021.030000
      copy-matrix-ops-per-sec: 430618.291788
      div-matrix-ops-per-sec: 484947.913990
      frobenius-matrix-ops-per-sec: 79558.559486
      hadamard-matrix-ops-per-sec: 357945.671171
      identity-matrix-ops-per-sec: 407136.809367
      mean-matrix-ops-per-sec: 404180.904255
      mult-matrix-ops-per-sec: 529748.243562
      negate-matrix-ops-per-sec: 549795.737870
      prod-matrix-ops-per-sec: 626.646449
      sub-matrix-ops-per-sec: 384952.265101
      square-matrix-ops-per-sec: 672.625040
      trans-matrix-ops-per-sec: 143877.720257
      zero-matrix-ops-per-sec: 864468.107227

...
