---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:48:21
      epoch-secs: 1795355301
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 399106
      totalram: 4080812032
      freeram: 2313887744
      sharedram: 3551232
      bufferram: 34299904
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 51997091
      bogo-ops-per-second-usr-sys-time: 433785.207080
      bogo-ops-per-second-real-time: 3466364.648005
      wall-clock-time: 15.000468
      user-time: 21.057511
      system-time: 98.810779
      cpu-usage-per-instance: 99.887127
      max-rss: 2588

...
