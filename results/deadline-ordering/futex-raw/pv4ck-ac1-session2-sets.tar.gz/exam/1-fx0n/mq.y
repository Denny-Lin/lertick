---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:36:12
      epoch-secs: 1795354572
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398376
      totalram: 4080812032
      freeram: 2330206208
      sharedram: 3551232
      bufferram: 33935360
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 40029155
      bogo-ops-per-second-usr-sys-time: 333924.951056
      bogo-ops-per-second-real-time: 2668522.285055
      wall-clock-time: 15.000495
      user-time: 16.559120
      system-time: 103.315585
      cpu-usage-per-instance: 99.892292
      max-rss: 2536

...
