---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:35:57
      epoch-secs: 1795354557
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398361
      totalram: 4080812032
      freeram: 2321784832
      sharedram: 3551232
      bufferram: 33935360
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 100068
      bogo-ops-per-second-usr-sys-time: 831.744576
      bogo-ops-per-second-real-time: 3335.493378
      wall-clock-time: 30.000959
      user-time: 3.966562
      system-time: 116.344412
      cpu-usage-per-instance: 50.127970
      max-rss: 2152

...
