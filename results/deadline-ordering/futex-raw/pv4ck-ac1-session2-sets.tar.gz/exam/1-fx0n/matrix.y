---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:36:27
      epoch-secs: 1795354587
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398391
      totalram: 4080812032
      freeram: 2331312128
      sharedram: 3551232
      bufferram: 33943552
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 537830
      bogo-ops-per-second-usr-sys-time: 4510.824360
      bogo-ops-per-second-real-time: 35853.180575
      wall-clock-time: 15.000901
      user-time: 119.213966
      system-time: 0.017012
      cpu-usage-per-instance: 99.353183
      max-rss: 2560
      add-matrix-ops-per-sec: 330733.670798
      copy-matrix-ops-per-sec: 448240.324887
      div-matrix-ops-per-sec: 481223.204511
      frobenius-matrix-ops-per-sec: 79985.397320
      hadamard-matrix-ops-per-sec: 364703.257190
      identity-matrix-ops-per-sec: 404062.781222
      mean-matrix-ops-per-sec: 427662.588247
      mult-matrix-ops-per-sec: 523248.426286
      negate-matrix-ops-per-sec: 545161.677667
      prod-matrix-ops-per-sec: 627.450142
      sub-matrix-ops-per-sec: 395529.143069
      square-matrix-ops-per-sec: 672.950843
      trans-matrix-ops-per-sec: 141677.637665
      zero-matrix-ops-per-sec: 841140.177581

...
