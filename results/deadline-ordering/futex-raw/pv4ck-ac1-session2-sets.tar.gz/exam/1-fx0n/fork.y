---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 13:36:42
      epoch-secs: 1795354602
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 398406
      totalram: 4080812032
      freeram: 2312675328
      sharedram: 3551232
      bufferram: 33943552
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 389535
      bogo-ops-per-second-usr-sys-time: 3267.088683
      bogo-ops-per-second-real-time: 25968.622273
      wall-clock-time: 15.000218
      user-time: 42.009437
      system-time: 77.220568
      cpu-usage-per-instance: 99.356892
      max-rss: 2280

...
