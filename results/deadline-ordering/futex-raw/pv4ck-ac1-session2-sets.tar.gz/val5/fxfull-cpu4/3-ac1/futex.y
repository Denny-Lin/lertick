---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:40:36
      epoch-secs: 1795358436
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 402240
      totalram: 4080812032
      freeram: 2852392960
      sharedram: 3522560
      bufferram: 42377216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23265052
      bogo-ops-per-second-usr-sys-time: 510853.689832
      bogo-ops-per-second-real-time: 1453981.599201
      wall-clock-time: 16.000926
      user-time: 4.842818
      system-time: 40.698699
      cpu-usage-per-instance: 71.154502
      max-rss: 2152

...
