---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:30:33
      epoch-secs: 1795357833
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401637
      totalram: 4080812032
      freeram: 2838872064
      sharedram: 3522560
      bufferram: 42037248
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 21432426
      bogo-ops-per-second-usr-sys-time: 473468.224766
      bogo-ops-per-second-real-time: 1339505.262613
      wall-clock-time: 16.000255
      user-time: 4.459753
      system-time: 40.807120
      cpu-usage-per-instance: 70.728361
      max-rss: 2152

...
