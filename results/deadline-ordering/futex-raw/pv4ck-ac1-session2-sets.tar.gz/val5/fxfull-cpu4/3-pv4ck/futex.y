---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:37:50
      epoch-secs: 1795358270
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 402074
      totalram: 4080812032
      freeram: 2844119040
      sharedram: 3522560
      bufferram: 42283008
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19747032
      bogo-ops-per-second-usr-sys-time: 441229.605509
      bogo-ops-per-second-real-time: 1234171.546187
      wall-clock-time: 16.000233
      user-time: 3.654807
      system-time: 41.099742
      cpu-usage-per-instance: 69.927966
      max-rss: 2152

...
