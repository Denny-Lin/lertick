---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:32:24
      epoch-secs: 1795357944
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401749
      totalram: 4080812032
      freeram: 2834288640
      sharedram: 3522560
      bufferram: 42082304
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23050
      bogo-ops-per-second-usr-sys-time: 719.326977
      bogo-ops-per-second-real-time: 1440.599251
      wall-clock-time: 16.000286
      user-time: 7.607856
      system-time: 24.435986
      cpu-usage-per-instance: 50.067608
      max-rss: 2148

...
