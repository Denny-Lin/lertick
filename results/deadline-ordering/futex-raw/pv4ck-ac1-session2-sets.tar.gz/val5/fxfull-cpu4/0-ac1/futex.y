---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:29:40
      epoch-secs: 1795357780
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401584
      totalram: 4080812032
      freeram: 2847993856
      sharedram: 3522560
      bufferram: 42000384
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 24454008
      bogo-ops-per-second-usr-sys-time: 536715.248445
      bogo-ops-per-second-real-time: 1528336.260424
      wall-clock-time: 16.000411
      user-time: 4.920022
      system-time: 40.642328
      cpu-usage-per-instance: 71.189344
      max-rss: 2176

...
