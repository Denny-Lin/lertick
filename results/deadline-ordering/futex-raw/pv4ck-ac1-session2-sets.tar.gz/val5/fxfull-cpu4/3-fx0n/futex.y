---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:39:41
      epoch-secs: 1795358381
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 402186
      totalram: 4080812032
      freeram: 2843938816
      sharedram: 3522560
      bufferram: 42328064
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 32384
      bogo-ops-per-second-usr-sys-time: 1010.337616
      bogo-ops-per-second-real-time: 2023.958478
      wall-clock-time: 16.000328
      user-time: 7.738795
      system-time: 24.313857
      cpu-usage-per-instance: 50.081241
      max-rss: 2180

...
