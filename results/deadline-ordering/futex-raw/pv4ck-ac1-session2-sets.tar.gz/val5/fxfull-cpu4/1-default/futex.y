---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:31:31
      epoch-secs: 1795357891
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401695
      totalram: 4080812032
      freeram: 2847838208
      sharedram: 3522560
      bufferram: 42065920
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28926302
      bogo-ops-per-second-usr-sys-time: 669073.696960
      bogo-ops-per-second-real-time: 1807856.375690
      wall-clock-time: 16.000332
      user-time: 5.834158
      system-time: 37.399199
      cpu-usage-per-instance: 67.550719
      max-rss: 2176

...
