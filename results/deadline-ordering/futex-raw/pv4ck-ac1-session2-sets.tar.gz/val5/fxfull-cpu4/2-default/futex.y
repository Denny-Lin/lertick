---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:35:10
      epoch-secs: 1795358110
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401915
      totalram: 4080812032
      freeram: 2847453184
      sharedram: 3522560
      bufferram: 42196992
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 27057902
      bogo-ops-per-second-usr-sys-time: 629734.710783
      bogo-ops-per-second-real-time: 1691087.672128
      wall-clock-time: 16.000295
      user-time: 5.664960
      system-time: 37.302184
      cpu-usage-per-instance: 67.134924
      max-rss: 2176

...
