---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:27:52
      epoch-secs: 1795357672
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401477
      totalram: 4080812032
      freeram: 2856648704
      sharedram: 3522560
      bufferram: 41930752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 27824866
      bogo-ops-per-second-usr-sys-time: 643888.970190
      bogo-ops-per-second-real-time: 1739006.192037
      wall-clock-time: 16.000441
      user-time: 5.642339
      system-time: 37.571425
      cpu-usage-per-instance: 67.519645
      max-rss: 2204

...
