---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:36:57
      epoch-secs: 1795358217
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 402021
      totalram: 4080812032
      freeram: 2835865600
      sharedram: 3522560
      bufferram: 42254336
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 24250296
      bogo-ops-per-second-usr-sys-time: 532269.784221
      bogo-ops-per-second-real-time: 1515620.700939
      wall-clock-time: 16.000241
      user-time: 5.040730
      system-time: 40.519429
      cpu-usage-per-instance: 71.186678
      max-rss: 2176

...
