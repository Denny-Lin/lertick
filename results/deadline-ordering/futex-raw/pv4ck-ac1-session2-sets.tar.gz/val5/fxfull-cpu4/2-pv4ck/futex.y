---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:34:12
      epoch-secs: 1795358052
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401856
      totalram: 4080812032
      freeram: 2840993792
      sharedram: 3522560
      bufferram: 42139648
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 17867838
      bogo-ops-per-second-usr-sys-time: 402369.271194
      bogo-ops-per-second-real-time: 1116719.706811
      wall-clock-time: 16.000289
      user-time: 3.246265
      system-time: 41.160302
      cpu-usage-per-instance: 69.384008
      max-rss: 2184

...
