---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:16:58
      epoch-secs: 1795357018
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400822
      totalram: 4080812032
      freeram: 2845405184
      sharedram: 3543040
      bufferram: 41582592
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 30694738
      bogo-ops-per-second-usr-sys-time: 356936.360059
      bogo-ops-per-second-real-time: 1917732.089999
      wall-clock-time: 16.005749
      user-time: 4.965095
      system-time: 81.029893
      cpu-usage-per-instance: 67.159454
      max-rss: 2180

...
