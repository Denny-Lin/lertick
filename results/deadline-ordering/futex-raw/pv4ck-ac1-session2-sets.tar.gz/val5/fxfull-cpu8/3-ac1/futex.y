---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:26:01
      epoch-secs: 1795357561
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401366
      totalram: 4080812032
      freeram: 2858553344
      sharedram: 3543040
      bufferram: 41869312
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 25365220
      bogo-ops-per-second-usr-sys-time: 280447.078630
      bogo-ops-per-second-real-time: 1585263.154939
      wall-clock-time: 16.000637
      user-time: 5.202498
      system-time: 85.243158
      cpu-usage-per-instance: 70.657856
      max-rss: 2180

...
