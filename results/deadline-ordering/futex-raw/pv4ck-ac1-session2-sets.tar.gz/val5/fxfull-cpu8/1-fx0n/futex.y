---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:17:51
      epoch-secs: 1795357071
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400876
      totalram: 4080812032
      freeram: 2862501888
      sharedram: 3543040
      bufferram: 41611264
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 51664
      bogo-ops-per-second-usr-sys-time: 805.087723
      bogo-ops-per-second-real-time: 3228.853686
      wall-clock-time: 16.000725
      user-time: 2.471023
      system-time: 61.700866
      cpu-usage-per-instance: 50.132017
      max-rss: 2152

...
