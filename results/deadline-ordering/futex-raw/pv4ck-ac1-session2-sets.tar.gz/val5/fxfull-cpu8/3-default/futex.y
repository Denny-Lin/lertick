---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:24:15
      epoch-secs: 1795357455
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401259
      totalram: 4080812032
      freeram: 2845155328
      sharedram: 3543040
      bufferram: 41791488
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 30034466
      bogo-ops-per-second-usr-sys-time: 349000.842846
      bogo-ops-per-second-real-time: 1876950.571984
      wall-clock-time: 16.001735
      user-time: 4.626240
      system-time: 81.432194
      cpu-usage-per-instance: 67.225861
      max-rss: 2176

...
