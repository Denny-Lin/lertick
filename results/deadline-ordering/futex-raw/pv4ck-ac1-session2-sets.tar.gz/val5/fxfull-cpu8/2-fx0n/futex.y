---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:21:31
      epoch-secs: 1795357291
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401095
      totalram: 4080812032
      freeram: 2858561536
      sharedram: 3543040
      bufferram: 41734144
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 51480
      bogo-ops-per-second-usr-sys-time: 801.977151
      bogo-ops-per-second-real-time: 3217.382492
      wall-clock-time: 16.000584
      user-time: 2.319778
      system-time: 61.871577
      cpu-usage-per-instance: 50.147665
      max-rss: 2176

...
