---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:23:18
      epoch-secs: 1795357398
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401202
      totalram: 4080812032
      freeram: 2859880448
      sharedram: 3543040
      bufferram: 41766912
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 18320296
      bogo-ops-per-second-usr-sys-time: 210006.212507
      bogo-ops-per-second-real-time: 1144942.190555
      wall-clock-time: 16.001066
      user-time: 5.148372
      system-time: 82.088552
      cpu-usage-per-instance: 68.149305
      max-rss: 2152

...
