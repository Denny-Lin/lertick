---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:19:39
      epoch-secs: 1795357179
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400983
      totalram: 4080812032
      freeram: 2861400064
      sharedram: 3543040
      bufferram: 41676800
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 16198948
      bogo-ops-per-second-usr-sys-time: 188985.849722
      bogo-ops-per-second-real-time: 1012383.871321
      wall-clock-time: 16.000796
      user-time: 4.866550
      system-time: 80.848587
      cpu-usage-per-instance: 66.961619
      max-rss: 2152

...
