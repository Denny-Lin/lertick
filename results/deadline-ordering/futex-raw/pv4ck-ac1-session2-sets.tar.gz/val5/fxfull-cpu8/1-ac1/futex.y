---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:18:45
      epoch-secs: 1795357125
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400929
      totalram: 4080812032
      freeram: 2844332032
      sharedram: 3543040
      bufferram: 41631744
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 25083212
      bogo-ops-per-second-usr-sys-time: 278096.398952
      bogo-ops-per-second-real-time: 1567619.795234
      wall-clock-time: 16.000826
      user-time: 5.285988
      system-time: 84.910117
      cpu-usage-per-instance: 70.462068
      max-rss: 2152

...
