---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:15:04
      epoch-secs: 1795356904
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400709
      totalram: 4080812032
      freeram: 2851614720
      sharedram: 3543040
      bufferram: 41533440
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 22187718
      bogo-ops-per-second-usr-sys-time: 245335.495191
      bogo-ops-per-second-real-time: 1386363.983490
      wall-clock-time: 16.004252
      user-time: 5.441407
      system-time: 84.996864
      cpu-usage-per-instance: 70.636129
      max-rss: 2152

...
