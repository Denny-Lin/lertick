---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:12:18
      epoch-secs: 1795356738
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400542
      totalram: 4080812032
      freeram: 3442388992
      sharedram: 3543040
      bufferram: 8224768
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 17851698
      bogo-ops-per-second-usr-sys-time: 205788.405179
      bogo-ops-per-second-real-time: 1115684.606183
      wall-clock-time: 16.000667
      user-time: 4.775235
      system-time: 81.972597
      cpu-usage-per-instance: 67.768918
      max-rss: 2152

...
