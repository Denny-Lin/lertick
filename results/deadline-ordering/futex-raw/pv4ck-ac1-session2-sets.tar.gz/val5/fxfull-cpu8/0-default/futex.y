---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:13:16
      epoch-secs: 1795356796
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 400601
      totalram: 4080812032
      freeram: 2877227008
      sharedram: 3543040
      bufferram: 41316352
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 31334418
      bogo-ops-per-second-usr-sys-time: 363310.687609
      bogo-ops-per-second-real-time: 1958315.569440
      wall-clock-time: 16.000699
      user-time: 4.822226
      system-time: 81.424667
      cpu-usage-per-instance: 67.377442
      max-rss: 2180

...
