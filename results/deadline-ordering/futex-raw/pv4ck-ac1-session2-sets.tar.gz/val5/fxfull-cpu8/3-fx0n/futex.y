---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 14:25:08
      epoch-secs: 1795357508
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 401313
      totalram: 4080812032
      freeram: 2863144960
      sharedram: 3543040
      bufferram: 41852928
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 58152
      bogo-ops-per-second-usr-sys-time: 906.169832
      bogo-ops-per-second-real-time: 3634.341154
      wall-clock-time: 16.000699
      user-time: 2.233403
      system-time: 61.939998
      cpu-usage-per-instance: 50.133278
      max-rss: 2152

...
