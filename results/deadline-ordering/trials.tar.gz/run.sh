#!/bin/bash
# One invocation per arm (the runner needs 5 repetitions); arm order shuffled.
cd ~/lertick-exp
mkdir -p runs
for arm in $(echo "default:base fixed:base online:base online:A online:B online:C" | tr ' ' '\n' | shuf --random-source=<(yes 20261115)); do
  pol=${arm%%:*}; b=${arm##*:}; out=runs/$b-$pol
  [ -f $out/done ] && continue
  rm -rf $out
  echo "$(date +%T) start $out" >> progress.log
  if sudo python3 $b/benchmarks/run_phase2.py --output $out --policies $pol \
      --workloads mixed,multicore,shortburst,wakeheavy --repetitions 5 \
      --seed 20261115 --cpus 0,1,2,3 --bpf-runtime > $out.log 2>&1; then
    touch $out/done; echo "$(date +%T) ok $out $(du -sh $out | cut -f1)" >> progress.log
  else
    echo "$(date +%T) FAIL $out $(tail -1 $out.log)" >> progress.log
  fi
  [ "$(cat /sys/kernel/sched_ext/state)" = disabled ] || { echo "$(date +%T) state not disabled, stop" >> progress.log; exit 1; }
done
echo "$(date +%T) all done" >> progress.log
