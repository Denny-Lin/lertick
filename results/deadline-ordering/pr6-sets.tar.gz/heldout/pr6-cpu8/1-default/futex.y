---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 16:56:50
      epoch-secs: 1795366610
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410414
      totalram: 4080812032
      freeram: 3177439232
      sharedram: 3543040
      bufferram: 37965824
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 31644968
      bogo-ops-per-second-usr-sys-time: 370173.232124
      bogo-ops-per-second-real-time: 1977764.901005
      wall-clock-time: 16.000369
      user-time: 5.010509
      system-time: 80.476407
      cpu-usage-per-instance: 66.785113
      max-rss: 2212

...
