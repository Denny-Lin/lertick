---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 16:53:08
      epoch-secs: 1795366388
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410192
      totalram: 4080812032
      freeram: 3200311296
      sharedram: 3543040
      bufferram: 34467840
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19290652
      bogo-ops-per-second-usr-sys-time: 220681.742598
      bogo-ops-per-second-real-time: 1205600.494938
      wall-clock-time: 16.000866
      user-time: 4.933539
      system-time: 82.480362
      cpu-usage-per-instance: 68.288414
      max-rss: 2152

...
