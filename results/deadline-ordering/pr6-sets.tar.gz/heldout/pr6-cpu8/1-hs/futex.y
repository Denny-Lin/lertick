---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 16:54:59
      epoch-secs: 1795366499
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410303
      totalram: 4080812032
      freeram: 3187924992
      sharedram: 3543040
      bufferram: 36618240
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 98036
      bogo-ops-per-second-usr-sys-time: 1527.301067
      bogo-ops-per-second-real-time: 6126.787413
      wall-clock-time: 16.001208
      user-time: 2.235861
      system-time: 61.953186
      cpu-usage-per-instance: 50.143907
      max-rss: 2152

...
