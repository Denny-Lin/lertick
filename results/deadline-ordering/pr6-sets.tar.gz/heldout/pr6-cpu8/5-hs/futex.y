---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:05:53
      epoch-secs: 1795367153
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410957
      totalram: 4080812032
      freeram: 3178430464
      sharedram: 3543040
      bufferram: 38268928
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 52214
      bogo-ops-per-second-usr-sys-time: 813.979356
      bogo-ops-per-second-real-time: 3263.253076
      wall-clock-time: 16.000598
      user-time: 2.211470
      system-time: 61.935120
      cpu-usage-per-instance: 50.112651
      max-rss: 2152

...
