---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:02:16
      epoch-secs: 1795366936
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410740
      totalram: 4080812032
      freeram: 3186204672
      sharedram: 3543040
      bufferram: 38166528
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 29846026
      bogo-ops-per-second-usr-sys-time: 352734.101735
      bogo-ops-per-second-real-time: 1865324.442423
      wall-clock-time: 16.000448
      user-time: 4.651490
      system-time: 79.961894
      cpu-usage-per-instance: 66.102357
      max-rss: 2180

...
