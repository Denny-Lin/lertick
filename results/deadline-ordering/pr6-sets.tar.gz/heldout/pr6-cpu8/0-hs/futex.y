---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 16:52:14
      epoch-secs: 1795366334
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410138
      totalram: 4080812032
      freeram: 3481419776
      sharedram: 3543040
      bufferram: 6795264
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 50770
      bogo-ops-per-second-usr-sys-time: 791.454437
      bogo-ops-per-second-real-time: 3172.947255
      wall-clock-time: 16.000896
      user-time: 2.280965
      system-time: 61.866758
      cpu-usage-per-instance: 50.112601
      max-rss: 2152

...
