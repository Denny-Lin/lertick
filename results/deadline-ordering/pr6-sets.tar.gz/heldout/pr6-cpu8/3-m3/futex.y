---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:01:19
      epoch-secs: 1795366879
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410683
      totalram: 4080812032
      freeram: 3176079360
      sharedram: 3543040
      bufferram: 38129664
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 20719722
      bogo-ops-per-second-usr-sys-time: 235365.245358
      bogo-ops-per-second-real-time: 1294907.733840
      wall-clock-time: 16.000925
      user-time: 5.158952
      system-time: 82.873255
      cpu-usage-per-instance: 68.771184
      max-rss: 2152

...
