---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 16:54:05
      epoch-secs: 1795366445
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410250
      totalram: 4080812032
      freeram: 3207958528
      sharedram: 3543040
      bufferram: 34500608
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 31547740
      bogo-ops-per-second-usr-sys-time: 365999.481670
      bogo-ops-per-second-real-time: 1971674.614919
      wall-clock-time: 16.000480
      user-time: 4.580944
      system-time: 81.615189
      cpu-usage-per-instance: 67.338709
      max-rss: 2176

...
