---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 16:55:53
      epoch-secs: 1795366553
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410357
      totalram: 4080812032
      freeram: 3184422912
      sharedram: 3543040
      bufferram: 37912576
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 20285014
      bogo-ops-per-second-usr-sys-time: 231374.431039
      bogo-ops-per-second-real-time: 1267724.032096
      wall-clock-time: 16.001128
      user-time: 5.223348
      system-time: 82.448457
      cpu-usage-per-instance: 68.488771
      max-rss: 2176

...
