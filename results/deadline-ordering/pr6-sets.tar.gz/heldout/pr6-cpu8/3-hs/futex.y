---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:00:25
      epoch-secs: 1795366825
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410629
      totalram: 4080812032
      freeram: 3185790976
      sharedram: 3543040
      bufferram: 38105088
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 51220
      bogo-ops-per-second-usr-sys-time: 798.487046
      bogo-ops-per-second-real-time: 3201.132030
      wall-clock-time: 16.000590
      user-time: 2.276372
      system-time: 61.869941
      cpu-usage-per-instance: 50.112460
      max-rss: 2176

...
