---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:03:08
      epoch-secs: 1795366988
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 410793
      totalram: 4080812032
      freeram: 3185324032
      sharedram: 3543040
      bufferram: 38195200
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 55136
      bogo-ops-per-second-usr-sys-time: 859.470321
      bogo-ops-per-second-real-time: 3445.866747
      wall-clock-time: 16.000619
      user-time: 2.406284
      system-time: 61.744855
      cpu-usage-per-instance: 50.116139
      max-rss: 2188

...
