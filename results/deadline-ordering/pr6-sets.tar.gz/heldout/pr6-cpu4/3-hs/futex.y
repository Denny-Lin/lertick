---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:16:49
      epoch-secs: 1795367809
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411613
      totalram: 4080812032
      freeram: 3189596160
      sharedram: 3522560
      bufferram: 38625280
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 24476
      bogo-ops-per-second-usr-sys-time: 764.002032
      bogo-ops-per-second-real-time: 1529.724259
      wall-clock-time: 16.000269
      user-time: 7.924538
      system-time: 24.112026
      cpu-usage-per-instance: 50.056289
      max-rss: 2180

...
