---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:12:14
      epoch-secs: 1795367534
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411338
      totalram: 4080812032
      freeram: 3188080640
      sharedram: 3522560
      bufferram: 38477824
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 21785006
      bogo-ops-per-second-usr-sys-time: 483048.816144
      bogo-ops-per-second-real-time: 1361539.497553
      wall-clock-time: 16.000275
      user-time: 4.177863
      system-time: 40.921111
      cpu-usage-per-instance: 70.465937
      max-rss: 2164

...
