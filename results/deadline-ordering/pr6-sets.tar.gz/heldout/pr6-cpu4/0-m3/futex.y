---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:09:30
      epoch-secs: 1795367370
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411175
      totalram: 4080812032
      freeram: 3189776384
      sharedram: 3522560
      bufferram: 38404096
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19093634
      bogo-ops-per-second-usr-sys-time: 429134.469259
      bogo-ops-per-second-real-time: 1193330.208678
      wall-clock-time: 16.000294
      user-time: 3.433641
      system-time: 41.059718
      cpu-usage-per-instance: 69.519597
      max-rss: 2152

...
