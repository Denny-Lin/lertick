---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:22:16
      epoch-secs: 1795368136
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411940
      totalram: 4080812032
      freeram: 3178602496
      sharedram: 3522560
      bufferram: 39239680
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 23640
      bogo-ops-per-second-usr-sys-time: 737.967109
      bogo-ops-per-second-real-time: 1477.472029
      wall-clock-time: 16.000303
      user-time: 7.994458
      system-time: 24.039490
      cpu-usage-per-instance: 50.052096
      max-rss: 2176

...
