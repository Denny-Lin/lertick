---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:20:26
      epoch-secs: 1795368026
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411830
      totalram: 4080812032
      freeram: 3180863488
      sharedram: 3522560
      bufferram: 39194624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 21134970
      bogo-ops-per-second-usr-sys-time: 470038.040332
      bogo-ops-per-second-real-time: 1320914.819895
      wall-clock-time: 16.000252
      user-time: 4.066752
      system-time: 40.897630
      cpu-usage-per-instance: 70.255740
      max-rss: 2152

...
