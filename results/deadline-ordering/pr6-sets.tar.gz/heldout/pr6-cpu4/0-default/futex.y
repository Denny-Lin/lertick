---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:10:28
      epoch-secs: 1795367428
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411232
      totalram: 4080812032
      freeram: 3198849024
      sharedram: 3522560
      bufferram: 38432768
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28722526
      bogo-ops-per-second-usr-sys-time: 664635.479847
      bogo-ops-per-second-real-time: 1795072.713929
      wall-clock-time: 16.000759
      user-time: 5.607856
      system-time: 37.607601
      cpu-usage-per-instance: 67.520948
      max-rss: 2176

...
