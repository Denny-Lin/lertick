---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:23:09
      epoch-secs: 1795368189
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411994
      totalram: 4080812032
      freeram: 3179409408
      sharedram: 3522560
      bufferram: 39268352
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 19876870
      bogo-ops-per-second-usr-sys-time: 445569.258071
      bogo-ops-per-second-real-time: 1242271.262940
      wall-clock-time: 16.000426
      user-time: 3.762281
      system-time: 40.847776
      cpu-usage-per-instance: 69.701356
      max-rss: 2180

...
