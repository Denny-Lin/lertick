---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:19:32
      epoch-secs: 1795367972
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411776
      totalram: 4080812032
      freeram: 3188568064
      sharedram: 3522560
      bufferram: 38727680
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 25670
      bogo-ops-per-second-usr-sys-time: 801.124908
      bogo-ops-per-second-real-time: 1604.331574
      wall-clock-time: 16.000433
      user-time: 8.115294
      system-time: 23.927150
      cpu-usage-per-instance: 50.064964
      max-rss: 2176

...
