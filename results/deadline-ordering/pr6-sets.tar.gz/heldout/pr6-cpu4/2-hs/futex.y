---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:14:04
      epoch-secs: 1795367644
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411449
      totalram: 4080812032
      freeram: 3185422336
      sharedram: 3522560
      bufferram: 38551552
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 24818
      bogo-ops-per-second-usr-sys-time: 774.658280
      bogo-ops-per-second-real-time: 1551.094306
      wall-clock-time: 16.000317
      user-time: 8.092323
      system-time: 23.945029
      cpu-usage-per-instance: 50.057372
      max-rss: 2152

...
