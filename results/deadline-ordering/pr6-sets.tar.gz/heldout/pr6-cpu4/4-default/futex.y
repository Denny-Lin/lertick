---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:21:23
      epoch-secs: 1795368083
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411887
      totalram: 4080812032
      freeram: 3186307072
      sharedram: 3522560
      bufferram: 39223296
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 28905644
      bogo-ops-per-second-usr-sys-time: 669107.188769
      bogo-ops-per-second-real-time: 1806565.842778
      wall-clock-time: 16.000327
      user-time: 5.764899
      system-time: 37.435420
      cpu-usage-per-instance: 67.499119
      max-rss: 2180

...
