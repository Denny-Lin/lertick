---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:22
      time-hh-mm-ss: 17:14:58
      epoch-secs: 1795367698
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 411502
      totalram: 4080812032
      freeram: 3187572736
      sharedram: 3522560
      bufferram: 38580224
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 21339358
      bogo-ops-per-second-usr-sys-time: 473956.274242
      bogo-ops-per-second-real-time: 1333689.827580
      wall-clock-time: 16.000241
      user-time: 4.318198
      system-time: 40.705698
      cpu-usage-per-instance: 70.348780
      max-rss: 2176

...
