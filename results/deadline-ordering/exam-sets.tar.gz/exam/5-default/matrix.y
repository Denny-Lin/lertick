---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:39:17
      epoch-secs: 1795113557
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157362
      totalram: 4080812032
      freeram: 1445167104
      sharedram: 3543040
      bufferram: 27148288
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 533918
      bogo-ops-per-second-usr-sys-time: 4451.124639
      bogo-ops-per-second-real-time: 35592.242295
      wall-clock-time: 15.000966
      user-time: 119.944256
      system-time: 0.007002
      cpu-usage-per-instance: 99.952948
      max-rss: 2664
      add-matrix-ops-per-sec: 332106.890350
      copy-matrix-ops-per-sec: 472566.383243
      div-matrix-ops-per-sec: 482487.069817
      frobenius-matrix-ops-per-sec: 79428.893459
      hadamard-matrix-ops-per-sec: 377558.243249
      identity-matrix-ops-per-sec: 387048.011587
      mean-matrix-ops-per-sec: 404917.145010
      mult-matrix-ops-per-sec: 536301.949249
      negate-matrix-ops-per-sec: 550282.030691
      prod-matrix-ops-per-sec: 622.230841
      sub-matrix-ops-per-sec: 420952.785198
      square-matrix-ops-per-sec: 668.385219
      trans-matrix-ops-per-sec: 144877.042050
      zero-matrix-ops-per-sec: 902126.779647

...
