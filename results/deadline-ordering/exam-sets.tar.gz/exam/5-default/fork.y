---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:39:32
      epoch-secs: 1795113572
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157377
      totalram: 4080812032
      freeram: 1365495808
      sharedram: 3543040
      bufferram: 27156480
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 241692
      bogo-ops-per-second-usr-sys-time: 2522.931487
      bogo-ops-per-second-real-time: 16112.441331
      wall-clock-time: 15.000334
      user-time: 33.312876
      system-time: 62.485207
      cpu-usage-per-instance: 79.829959
      max-rss: 2284

...
