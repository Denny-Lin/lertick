---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:39:02
      epoch-secs: 1795113542
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157347
      totalram: 4080812032
      freeram: 1429770240
      sharedram: 3543040
      bufferram: 27144192
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 40927908
      bogo-ops-per-second-usr-sys-time: 359809.694284
      bogo-ops-per-second-real-time: 2728101.054540
      wall-clock-time: 15.002343
      user-time: 17.905149
      system-time: 95.843615
      cpu-usage-per-instance: 94.775832
      max-rss: 2448

...
