---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:38:47
      epoch-secs: 1795113527
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157331
      totalram: 4080812032
      freeram: 1440722944
      sharedram: 3543040
      bufferram: 27136000
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 56503588
      bogo-ops-per-second-usr-sys-time: 358367.379614
      bogo-ops-per-second-real-time: 1883416.763037
      wall-clock-time: 30.000576
      user-time: 9.109375
      system-time: 148.560076
      cpu-usage-per-instance: 65.694343
      max-rss: 2176

...
