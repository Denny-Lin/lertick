---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:34:44
      epoch-secs: 1795113284
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157088
      totalram: 4080812032
      freeram: 1437564928
      sharedram: 3543040
      bufferram: 27025408
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 531880
      bogo-ops-per-second-usr-sys-time: 4477.566456
      bogo-ops-per-second-real-time: 35456.497361
      wall-clock-time: 15.000918
      user-time: 118.779739
      system-time: 0.008001
      cpu-usage-per-instance: 98.983727
      max-rss: 2560
      add-matrix-ops-per-sec: 323969.726898
      copy-matrix-ops-per-sec: 422068.032026
      div-matrix-ops-per-sec: 489011.518312
      frobenius-matrix-ops-per-sec: 78900.795386
      hadamard-matrix-ops-per-sec: 389532.044200
      identity-matrix-ops-per-sec: 395270.217570
      mean-matrix-ops-per-sec: 408802.923226
      mult-matrix-ops-per-sec: 538601.494190
      negate-matrix-ops-per-sec: 525809.035792
      prod-matrix-ops-per-sec: 620.453574
      sub-matrix-ops-per-sec: 412311.021854
      square-matrix-ops-per-sec: 665.431556
      trans-matrix-ops-per-sec: 141863.346654
      zero-matrix-ops-per-sec: 853938.197973

...
