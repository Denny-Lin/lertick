---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:34:14
      epoch-secs: 1795113254
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157058
      totalram: 4080812032
      freeram: 1426489344
      sharedram: 3543040
      bufferram: 27017216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 109946
      bogo-ops-per-second-usr-sys-time: 913.510817
      bogo-ops-per-second-real-time: 3664.550483
      wall-clock-time: 30.002588
      user-time: 5.598565
      system-time: 114.756879
      cpu-usage-per-instance: 50.143775
      max-rss: 2176

...
