---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:31:42
      epoch-secs: 1795113102
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156906
      totalram: 4080812032
      freeram: 1430609920
      sharedram: 3543040
      bufferram: 26943488
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 534048
      bogo-ops-per-second-usr-sys-time: 4457.636081
      bogo-ops-per-second-real-time: 35601.005160
      wall-clock-time: 15.000925
      user-time: 119.799202
      system-time: 0.006002
      cpu-usage-per-instance: 99.831515
      max-rss: 2664
      add-matrix-ops-per-sec: 328070.074187
      copy-matrix-ops-per-sec: 454720.514201
      div-matrix-ops-per-sec: 488104.834439
      frobenius-matrix-ops-per-sec: 78647.615294
      hadamard-matrix-ops-per-sec: 401659.357413
      identity-matrix-ops-per-sec: 409530.956017
      mean-matrix-ops-per-sec: 423986.425403
      mult-matrix-ops-per-sec: 508142.849931
      negate-matrix-ops-per-sec: 538274.260056
      prod-matrix-ops-per-sec: 623.313543
      sub-matrix-ops-per-sec: 405330.816074
      square-matrix-ops-per-sec: 667.644682
      trans-matrix-ops-per-sec: 143974.478434
      zero-matrix-ops-per-sec: 843662.403700

...
