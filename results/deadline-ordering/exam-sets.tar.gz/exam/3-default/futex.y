---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:31:12
      epoch-secs: 1795113072
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156876
      totalram: 4080812032
      freeram: 1426391040
      sharedram: 3543040
      bufferram: 26935296
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 53606460
      bogo-ops-per-second-usr-sys-time: 337132.535231
      bogo-ops-per-second-real-time: 1786826.471029
      wall-clock-time: 30.000932
      user-time: 9.268943
      system-time: 149.738137
      cpu-usage-per-instance: 66.250891
      max-rss: 2152

...
