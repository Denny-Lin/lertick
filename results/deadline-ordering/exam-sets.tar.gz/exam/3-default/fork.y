---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:31:57
      epoch-secs: 1795113117
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156921
      totalram: 4080812032
      freeram: 1337040896
      sharedram: 3543040
      bufferram: 26943488
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 277556
      bogo-ops-per-second-usr-sys-time: 2788.876887
      bogo-ops-per-second-real-time: 18503.277843
      wall-clock-time: 15.000369
      user-time: 35.727107
      system-time: 63.795393
      cpu-usage-per-instance: 82.933375
      max-rss: 2328

...
