---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:25:13
      epoch-secs: 1795112713
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156517
      totalram: 4080812032
      freeram: 1439989760
      sharedram: 3543040
      bufferram: 26013696
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 42828078
      bogo-ops-per-second-usr-sys-time: 357843.806994
      bogo-ops-per-second-real-time: 2855090.546313
      wall-clock-time: 15.000602
      user-time: 19.263967
      system-time: 100.419753
      cpu-usage-per-instance: 99.732428
      max-rss: 2564

...
