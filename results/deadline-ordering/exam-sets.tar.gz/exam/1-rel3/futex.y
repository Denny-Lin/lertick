---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:24:58
      epoch-secs: 1795112698
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156502
      totalram: 4080812032
      freeram: 1437065216
      sharedram: 3543040
      bufferram: 26013696
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 108218
      bogo-ops-per-second-usr-sys-time: 898.741779
      bogo-ops-per-second-real-time: 3606.174160
      wall-clock-time: 30.009089
      user-time: 4.634517
      system-time: 115.776042
      cpu-usage-per-instance: 50.155871
      max-rss: 2180

...
