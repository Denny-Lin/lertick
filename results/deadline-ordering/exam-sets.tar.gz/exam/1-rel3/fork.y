---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:25:43
      epoch-secs: 1795112743
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156547
      totalram: 4080812032
      freeram: 1433321472
      sharedram: 3543040
      bufferram: 26021888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 343148
      bogo-ops-per-second-usr-sys-time: 2881.671682
      bogo-ops-per-second-real-time: 22876.164409
      wall-clock-time: 15.000242
      user-time: 39.652606
      system-time: 79.426886
      cpu-usage-per-instance: 99.231310
      max-rss: 2280

...
