---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:25:28
      epoch-secs: 1795112728
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156532
      totalram: 4080812032
      freeram: 1442308096
      sharedram: 3543040
      bufferram: 26021888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 484112
      bogo-ops-per-second-usr-sys-time: 4080.940107
      bogo-ops-per-second-real-time: 32269.649390
      wall-clock-time: 15.002084
      user-time: 118.576349
      system-time: 0.051219
      cpu-usage-per-instance: 98.842572
      max-rss: 2564
      add-matrix-ops-per-sec: 301676.345277
      copy-matrix-ops-per-sec: 451538.361047
      div-matrix-ops-per-sec: 424922.788105
      frobenius-matrix-ops-per-sec: 74056.516985
      hadamard-matrix-ops-per-sec: 349044.477922
      identity-matrix-ops-per-sec: 366806.716594
      mean-matrix-ops-per-sec: 382302.671428
      mult-matrix-ops-per-sec: 492669.178783
      negate-matrix-ops-per-sec: 510055.157921
      prod-matrix-ops-per-sec: 560.682226
      sub-matrix-ops-per-sec: 360766.401544
      square-matrix-ops-per-sec: 609.845608
      trans-matrix-ops-per-sec: 132702.989819
      zero-matrix-ops-per-sec: 818575.403574

...
