---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:30:11
      epoch-secs: 1795113011
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156815
      totalram: 4080812032
      freeram: 1372577792
      sharedram: 3543040
      bufferram: 26906624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 507755
      bogo-ops-per-second-usr-sys-time: 4239.444436
      bogo-ops-per-second-real-time: 33848.525425
      wall-clock-time: 15.000801
      user-time: 119.756192
      system-time: 0.013039
      cpu-usage-per-instance: 99.802362
      max-rss: 2664
      add-matrix-ops-per-sec: 310033.121774
      copy-matrix-ops-per-sec: 436253.343449
      div-matrix-ops-per-sec: 432216.161172
      frobenius-matrix-ops-per-sec: 75916.518912
      hadamard-matrix-ops-per-sec: 347081.467312
      identity-matrix-ops-per-sec: 368618.339109
      mean-matrix-ops-per-sec: 405728.324065
      mult-matrix-ops-per-sec: 506077.550523
      negate-matrix-ops-per-sec: 510074.442388
      prod-matrix-ops-per-sec: 590.177274
      sub-matrix-ops-per-sec: 389169.348659
      square-matrix-ops-per-sec: 637.675263
      trans-matrix-ops-per-sec: 136778.363282
      zero-matrix-ops-per-sec: 810115.000245

...
