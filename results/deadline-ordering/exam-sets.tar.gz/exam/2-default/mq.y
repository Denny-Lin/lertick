---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:29:56
      epoch-secs: 1795112996
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156800
      totalram: 4080812032
      freeram: 1357344768
      sharedram: 3543040
      bufferram: 26898432
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 41206369
      bogo-ops-per-second-usr-sys-time: 355427.856878
      bogo-ops-per-second-real-time: 2746713.195312
      wall-clock-time: 15.002065
      user-time: 18.247890
      system-time: 97.686661
      cpu-usage-per-instance: 96.598829
      max-rss: 2472

...
