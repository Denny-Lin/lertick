---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:30:26
      epoch-secs: 1795113026
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156830
      totalram: 4080812032
      freeram: 1186017280
      sharedram: 3543040
      bufferram: 26906624
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 202635
      bogo-ops-per-second-usr-sys-time: 2178.471394
      bogo-ops-per-second-real-time: 13508.662174
      wall-clock-time: 15.000375
      user-time: 29.804113
      system-time: 63.212945
      cpu-usage-per-instance: 77.512277
      max-rss: 2308

...
