---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:29:41
      epoch-secs: 1795112981
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156785
      totalram: 4080812032
      freeram: 1368682496
      sharedram: 3543040
      bufferram: 26898432
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 56653060
      bogo-ops-per-second-usr-sys-time: 352503.758691
      bogo-ops-per-second-real-time: 1888407.722887
      wall-clock-time: 30.000439
      user-time: 8.588972
      system-time: 152.127215
      cpu-usage-per-instance: 66.964099
      max-rss: 2184

...
