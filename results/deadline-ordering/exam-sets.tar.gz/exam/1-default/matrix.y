---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:27:01
      epoch-secs: 1795112821
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156625
      totalram: 4080812032
      freeram: 1368387584
      sharedram: 3543040
      bufferram: 27021312
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 460800
      bogo-ops-per-second-usr-sys-time: 3850.103377
      bogo-ops-per-second-real-time: 30717.021895
      wall-clock-time: 15.001454
      user-time: 119.666985
      system-time: 0.018113
      cpu-usage-per-instance: 99.727913
      max-rss: 2664
      add-matrix-ops-per-sec: 294341.960743
      copy-matrix-ops-per-sec: 440890.662762
      div-matrix-ops-per-sec: 409523.949001
      frobenius-matrix-ops-per-sec: 72119.097006
      hadamard-matrix-ops-per-sec: 334563.198288
      identity-matrix-ops-per-sec: 338180.589021
      mean-matrix-ops-per-sec: 347455.292225
      mult-matrix-ops-per-sec: 457480.339691
      negate-matrix-ops-per-sec: 453320.059607
      prod-matrix-ops-per-sec: 529.613483
      sub-matrix-ops-per-sec: 345694.357985
      square-matrix-ops-per-sec: 585.506861
      trans-matrix-ops-per-sec: 122807.986041
      zero-matrix-ops-per-sec: 824234.582286

...
