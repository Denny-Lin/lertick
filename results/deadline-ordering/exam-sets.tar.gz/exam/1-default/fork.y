---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:27:16
      epoch-secs: 1795112836
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156640
      totalram: 4080812032
      freeram: 1236717568
      sharedram: 3543040
      bufferram: 27025408
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 251182
      bogo-ops-per-second-usr-sys-time: 2567.697488
      bogo-ops-per-second-real-time: 16745.153267
      wall-clock-time: 15.000281
      user-time: 33.555598
      system-time: 64.268231
      cpu-usage-per-instance: 81.518332
      max-rss: 2308

...
