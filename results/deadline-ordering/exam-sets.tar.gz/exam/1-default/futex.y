---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:26:31
      epoch-secs: 1795112791
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156595
      totalram: 4080812032
      freeram: 1353912320
      sharedram: 3543040
      bufferram: 27017216
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 58531124
      bogo-ops-per-second-usr-sys-time: 362319.307626
      bogo-ops-per-second-real-time: 1951000.889990
      wall-clock-time: 30.000562
      user-time: 9.008268
      system-time: 152.537426
      cpu-usage-per-instance: 67.309444
      max-rss: 2180

...
