---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:26:46
      epoch-secs: 1795112806
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156610
      totalram: 4080812032
      freeram: 1351467008
      sharedram: 3543040
      bufferram: 27021312
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 37448739
      bogo-ops-per-second-usr-sys-time: 336093.838118
      bogo-ops-per-second-real-time: 2496006.667675
      wall-clock-time: 15.003461
      user-time: 17.051672
      system-time: 94.371790
      cpu-usage-per-instance: 92.831465
      max-rss: 2604

...
