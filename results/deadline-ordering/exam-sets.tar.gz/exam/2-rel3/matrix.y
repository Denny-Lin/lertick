---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:28:35
      epoch-secs: 1795112915
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156719
      totalram: 4080812032
      freeram: 1353428992
      sharedram: 3543040
      bufferram: 26890240
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 494670
      bogo-ops-per-second-usr-sys-time: 4149.409824
      bogo-ops-per-second-real-time: 32972.499479
      wall-clock-time: 15.002502
      user-time: 119.162391
      system-time: 0.052153
      cpu-usage-per-instance: 99.328883
      max-rss: 2560
      add-matrix-ops-per-sec: 304709.470203
      copy-matrix-ops-per-sec: 446975.150522
      div-matrix-ops-per-sec: 442700.463028
      frobenius-matrix-ops-per-sec: 75418.270441
      hadamard-matrix-ops-per-sec: 344483.476332
      identity-matrix-ops-per-sec: 358643.160044
      mean-matrix-ops-per-sec: 386722.736868
      mult-matrix-ops-per-sec: 473795.729521
      negate-matrix-ops-per-sec: 500266.947752
      prod-matrix-ops-per-sec: 572.111632
      sub-matrix-ops-per-sec: 362819.102978
      square-matrix-ops-per-sec: 624.464919
      trans-matrix-ops-per-sec: 131900.000469
      zero-matrix-ops-per-sec: 898770.234611

...
