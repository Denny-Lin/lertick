---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:28:19
      epoch-secs: 1795112899
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156704
      totalram: 4080812032
      freeram: 1353396224
      sharedram: 3543040
      bufferram: 26877952
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 41605788
      bogo-ops-per-second-usr-sys-time: 347410.311220
      bogo-ops-per-second-real-time: 2773586.509750
      wall-clock-time: 15.000718
      user-time: 20.078239
      system-time: 99.681557
      cpu-usage-per-instance: 99.795056
      max-rss: 2536

...
