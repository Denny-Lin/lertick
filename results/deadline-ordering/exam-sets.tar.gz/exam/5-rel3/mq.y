---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:37:31
      epoch-secs: 1795113451
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157255
      totalram: 4080812032
      freeram: 1427832832
      sharedram: 3543040
      bufferram: 27082752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 42758045
      bogo-ops-per-second-usr-sys-time: 356559.716210
      bogo-ops-per-second-real-time: 2850367.593472
      wall-clock-time: 15.000888
      user-time: 19.068000
      system-time: 100.850328
      cpu-usage-per-instance: 99.926024
      max-rss: 2564

...
