---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:37:16
      epoch-secs: 1795113436
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157240
      totalram: 4080812032
      freeram: 1424162816
      sharedram: 3543040
      bufferram: 27074560
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 98426
      bogo-ops-per-second-usr-sys-time: 818.343152
      bogo-ops-per-second-real-time: 3280.801881
      wall-clock-time: 30.000592
      user-time: 3.842827
      system-time: 116.431901
      cpu-usage-per-instance: 50.113480
      max-rss: 2152

...
