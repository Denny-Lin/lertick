---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:37:46
      epoch-secs: 1795113466
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157270
      totalram: 4080812032
      freeram: 1435041792
      sharedram: 3543040
      bufferram: 27082752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 536312
      bogo-ops-per-second-usr-sys-time: 4492.836047
      bogo-ops-per-second-real-time: 35751.557998
      wall-clock-time: 15.001081
      user-time: 119.348438
      system-time: 0.022043
      cpu-usage-per-instance: 99.468236
      max-rss: 2560
      add-matrix-ops-per-sec: 338988.276450
      copy-matrix-ops-per-sec: 452298.237667
      div-matrix-ops-per-sec: 460847.534205
      frobenius-matrix-ops-per-sec: 80925.225364
      hadamard-matrix-ops-per-sec: 366661.484568
      identity-matrix-ops-per-sec: 366187.652323
      mean-matrix-ops-per-sec: 420635.408860
      mult-matrix-ops-per-sec: 523192.814540
      negate-matrix-ops-per-sec: 544869.502103
      prod-matrix-ops-per-sec: 627.510807
      sub-matrix-ops-per-sec: 406352.856660
      square-matrix-ops-per-sec: 668.859816
      trans-matrix-ops-per-sec: 145089.687563
      zero-matrix-ops-per-sec: 870616.314403

...
