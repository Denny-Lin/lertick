---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:38:01
      epoch-secs: 1795113481
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157285
      totalram: 4080812032
      freeram: 1414209536
      sharedram: 3543040
      bufferram: 27082752
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 388483
      bogo-ops-per-second-usr-sys-time: 3252.343533
      bogo-ops-per-second-real-time: 25898.501743
      wall-clock-time: 15.000211
      user-time: 42.204980
      system-time: 77.242119
      cpu-usage-per-instance: 99.537847
      max-rss: 2312

...
