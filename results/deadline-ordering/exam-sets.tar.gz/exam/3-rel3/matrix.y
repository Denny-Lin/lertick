---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:33:13
      epoch-secs: 1795113193
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156997
      totalram: 4080812032
      freeram: 1438924800
      sharedram: 3543040
      bufferram: 26968064
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 537378
      bogo-ops-per-second-usr-sys-time: 4523.926291
      bogo-ops-per-second-real-time: 35823.172032
      wall-clock-time: 15.000849
      user-time: 118.775748
      system-time: 0.010007
      cpu-usage-per-instance: 98.982526
      max-rss: 2664
      add-matrix-ops-per-sec: 323225.686093
      copy-matrix-ops-per-sec: 430412.059059
      div-matrix-ops-per-sec: 503194.686032
      frobenius-matrix-ops-per-sec: 81098.978192
      hadamard-matrix-ops-per-sec: 368073.026759
      identity-matrix-ops-per-sec: 401445.142339
      mean-matrix-ops-per-sec: 423539.463044
      mult-matrix-ops-per-sec: 530116.428091
      negate-matrix-ops-per-sec: 517430.462335
      prod-matrix-ops-per-sec: 627.193580
      sub-matrix-ops-per-sec: 405263.492387
      square-matrix-ops-per-sec: 671.912869
      trans-matrix-ops-per-sec: 142643.800182
      zero-matrix-ops-per-sec: 894156.557697

...
