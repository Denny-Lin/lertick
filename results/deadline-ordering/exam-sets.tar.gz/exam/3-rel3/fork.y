---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:33:28
      epoch-secs: 1795113208
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157012
      totalram: 4080812032
      freeram: 1428283392
      sharedram: 3543040
      bufferram: 26992640
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 396791
      bogo-ops-per-second-usr-sys-time: 3319.968984
      bogo-ops-per-second-real-time: 26452.368909
      wall-clock-time: 15.000207
      user-time: 42.971606
      system-time: 76.544872
      cpu-usage-per-instance: 99.595693
      max-rss: 2308

...
