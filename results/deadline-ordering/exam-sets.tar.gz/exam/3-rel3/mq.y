---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:32:58
      epoch-secs: 1795113178
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156982
      totalram: 4080812032
      freeram: 1430253568
      sharedram: 3543040
      bufferram: 26968064
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: mq
      bogo-ops: 41075920
      bogo-ops-per-second-usr-sys-time: 342774.922112
      bogo-ops-per-second-real-time: 2738293.473361
      wall-clock-time: 15.000554
      user-time: 16.994908
      system-time: 102.838596
      cpu-usage-per-instance: 99.857563
      max-rss: 2536

...
