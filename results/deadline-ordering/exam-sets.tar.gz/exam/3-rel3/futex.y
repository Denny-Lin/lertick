---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:32:43
      epoch-secs: 1795113163
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 156967
      totalram: 4080812032
      freeram: 1430740992
      sharedram: 3543040
      bufferram: 26955776
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 100344
      bogo-ops-per-second-usr-sys-time: 834.418933
      bogo-ops-per-second-real-time: 3344.692688
      wall-clock-time: 30.000963
      user-time: 4.967425
      system-time: 115.288715
      cpu-usage-per-instance: 50.105117
      max-rss: 2176

...
