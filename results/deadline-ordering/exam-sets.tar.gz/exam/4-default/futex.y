---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:35:45
      epoch-secs: 1795113345
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157150
      totalram: 4080812032
      freeram: 1433931776
      sharedram: 3543040
      bufferram: 27045888
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: futex
      bogo-ops: 56342384
      bogo-ops-per-second-usr-sys-time: 351744.605016
      bogo-ops-per-second-real-time: 1877992.905707
      wall-clock-time: 30.001383
      user-time: 8.284430
      system-time: 151.895380
      cpu-usage-per-instance: 66.738511
      max-rss: 2176

...
