---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:36:30
      epoch-secs: 1795113390
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157195
      totalram: 4080812032
      freeram: 1330192384
      sharedram: 3543040
      bufferram: 27058176
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: fork
      bogo-ops: 265570
      bogo-ops-per-second-usr-sys-time: 2716.619180
      bogo-ops-per-second-real-time: 17704.273513
      wall-clock-time: 15.000333
      user-time: 35.038557
      system-time: 62.718980
      cpu-usage-per-instance: 81.462805
      max-rss: 2280

...
