---
system-info:
      stress-ng-version: 0.17.06
      run-by: ubuntu
      date-yyyy-mm-dd: 2026:11:19
      time-hh-mm-ss: 18:36:15
      epoch-secs: 1795113375
      hostname: lertick-vm
      sysname: Linux
      nodename: lertick-vm
      release: 7.0.0-43-generic
      version: '#43~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Sat Oct 31 07:32:05 UTC 2'
      machine: aarch64
      compiler: 'gcc 13.2.0'
      uptime: 157180
      totalram: 4080812032
      freeram: 1446907904
      sharedram: 3543040
      bufferram: 27049984
      totalswap: 0
      freeswap: 0
      pagesize: 4096
      cpus: 8
      cpus-online: 8
      ticks-per-second: 100

metrics:
    - stressor: matrix
      bogo-ops: 538611
      bogo-ops-per-second-usr-sys-time: 4488.308080
      bogo-ops-per-second-real-time: 35905.185693
      wall-clock-time: 15.000925
      user-time: 119.997122
      system-time: 0.006004
      cpu-usage-per-instance: 99.996438
      max-rss: 2668
      add-matrix-ops-per-sec: 327022.691895
      copy-matrix-ops-per-sec: 462664.193078
      div-matrix-ops-per-sec: 473002.829227
      frobenius-matrix-ops-per-sec: 80592.148616
      hadamard-matrix-ops-per-sec: 375885.851854
      identity-matrix-ops-per-sec: 396696.704389
      mean-matrix-ops-per-sec: 425162.375147
      mult-matrix-ops-per-sec: 507308.561680
      negate-matrix-ops-per-sec: 534262.625713
      prod-matrix-ops-per-sec: 629.057344
      sub-matrix-ops-per-sec: 408795.271132
      square-matrix-ops-per-sec: 672.945116
      trans-matrix-ops-per-sec: 144556.773936
      zero-matrix-ops-per-sec: 840568.896106

...
